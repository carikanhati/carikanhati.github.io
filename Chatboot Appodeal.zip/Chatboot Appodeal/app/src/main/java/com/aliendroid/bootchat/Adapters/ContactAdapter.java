package com.aliendroid.bootchat.Adapters;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.aliendroid.bootchat.Activity.MainActivity;
import com.aliendroid.bootchat.Model.Video;
import com.aliendroid.bootchat.blackbot.R;
import com.appodeal.ads.Appodeal;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import com.squareup.picasso.Picasso;
import com.startapp.sdk.adsbase.StartAppAd;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.aliendroid.bootchat.UtilityPackage.Settings.ADMOB_INTER;
import static com.aliendroid.bootchat.UtilityPackage.Settings.APPODEAL_ID;
import static com.aliendroid.bootchat.UtilityPackage.Settings.COUNTER;
import static com.aliendroid.bootchat.UtilityPackage.Settings.FAN_INTER;
import static com.aliendroid.bootchat.UtilityPackage.Settings.INTERVAL2;
import static com.aliendroid.bootchat.UtilityPackage.Settings.INTER_MOPUB;
import static com.aliendroid.bootchat.UtilityPackage.Settings.SELECT_ADS;


public class ContactAdapter extends RecyclerView.Adapter {

    public static ArrayList<Video> webLists;
    public static ArrayList<Video> mFilteredList;
    public Context context;
    public static String posisi;
    public static String judul;
    public static String gambar;

    private InterstitialAd mInterstitialAd;
    public static com.facebook.ads.InterstitialAd interstitialAdfb;
    public ContactAdapter(ArrayList<Video> webLists, Context context) {
        mFilteredList = webLists;
        ContactAdapter.webLists = webLists;
        this.context = context;
    }

    public class ViewHolder extends RecyclerView.ViewHolder  {
        public TextView judul_vid;
        public TextView deskrispi;
        public CircleImageView avatar_url;
        public RelativeLayout layVid;

        public ViewHolder(View itemView) {
            super(itemView);
            judul_vid = (TextView) itemView.findViewById(R.id.txtJudul);
            deskrispi = (TextView) itemView.findViewById(R.id.txtDes);
            avatar_url = (CircleImageView) itemView.findViewById(R.id.gbrvideo);
            layVid = itemView.findViewById(R.id.layvid);
            switch (SELECT_ADS) {
                case "ADMOB":
                    loadadmobinter();
                    break;
                case "FACEBOOK":
                    interstitialAdfb = new com.facebook.ads.InterstitialAd(context, FAN_INTER);
                    interstitialAdfb.loadAd();
                    break;

                case "APPODEAL":
                loadappodealinter();
                break;


            }
        }

    }

    private void loadadmobinter() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(context,ADMOB_INTER, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                mInterstitialAd = interstitialAd;
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                mInterstitialAd = null;
            }
        });
    }


    private void tampiladmobinter() {
        if (mInterstitialAd != null) {
            mInterstitialAd.show((Activity)context);
        } else {
            StartAppAd.showAd((Activity)context);
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_contact, parent, false);
            return new ViewHolder(v);
    }


    @Override
    public void onBindViewHolder(@NonNull final RecyclerView.ViewHolder holder, final int position) {

                if (holder instanceof ViewHolder) {
                    final Video webList = mFilteredList.get(position);
                    ((ViewHolder)holder).judul_vid.setText(webList.getJudul_url());
                    ((ViewHolder)holder).deskrispi.setText(webList.getDes_vid());

                    Glide.with(context).load(webList.getGambar_url())
                            .centerCrop().into( ((ViewHolder)holder).avatar_url);

                    ((ViewHolder)holder).layVid.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            posisi = webList.getVideo_url();
                            judul = webList.getJudul_url();
                            gambar = webList.getGambar_url();
                            Intent intent = new Intent(context, MainActivity.class);
                            intent.putExtra("position", position);
                            context.startActivity(intent);

                            if (COUNTER>Integer.parseInt(INTERVAL2)){
                                switch (SELECT_ADS) {
                                    case "ADMOB":
                                        tampiladmobinter();
                                        break;
                                    case "FACEBOOK":
                                        if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                                            interstitialAdfb.loadAd();
                                        } else {
                                            interstitialAdfb.show();
                                            interstitialAdfb.loadAd();
                                        }
                                        break;

                                    case "STARTAPP":
                                        StartAppAd.showAd(context);
                                        break;

                                    case "APPODEAL":
                                        tampilappodealinter();
                                        break;

                                        
                                }
                                COUNTER=0;
                            } else {
                                switch (SELECT_ADS) {
                                    case "ADMOB":
                                        loadadmobinter();
                                        break;
                                    case "FACEBOOK":
                                        if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                                            assert interstitialAdfb != null;
                                            interstitialAdfb.loadAd();
                                        }
                                        break;
                                    case "APPODEAL":
                                        loadappodealinter();
                                        break;

                                }
                                COUNTER++;
                            }
                        }
                    });

                }
    }

    private void tampilappodealinter() {
        Appodeal.isLoaded(Appodeal.INTERSTITIAL);
        Appodeal.show((Activity) context, Appodeal.INTERSTITIAL);
    }

    private void loadappodealinter() {
        Appodeal.initialize((Activity) context, APPODEAL_ID, Appodeal.INTERSTITIAL);
        Appodeal.cache((Activity) context, Appodeal.INTERSTITIAL);
        Appodeal.getPredictedEcpm(Appodeal.INTERSTITIAL);
    }

    @Override

    public int getItemCount() {
        return mFilteredList.size();
    }

    public Filter getFilter() {

        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {

                String charString = charSequence.toString();

                if (charString.isEmpty()) {

                    mFilteredList = webLists;
                } else {

                    ArrayList<Video> filteredList = new ArrayList<>();

                    for (Video androidVersion : mFilteredList) {

                        if (androidVersion.getJudul_url().toLowerCase().contains(charString) || androidVersion.getDes_vid().toLowerCase().contains(charString)) {

                            filteredList.add(androidVersion);
                        }
                    }

                    mFilteredList = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = mFilteredList;
                return filterResults;
            }

            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                mFilteredList = (ArrayList<Video>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }
}
