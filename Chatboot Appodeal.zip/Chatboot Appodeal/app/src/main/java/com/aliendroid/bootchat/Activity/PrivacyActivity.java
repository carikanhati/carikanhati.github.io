package com.aliendroid.bootchat.Activity;

public class PrivacyActivity {
}
