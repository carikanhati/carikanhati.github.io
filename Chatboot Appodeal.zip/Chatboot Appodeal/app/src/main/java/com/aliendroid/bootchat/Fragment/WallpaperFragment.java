package com.aliendroid.bootchat.Fragment;

import android.app.Activity;
import android.app.ProgressDialog;
import android.app.WallpaperManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.aliendroid.bootchat.Activity.SplashActivity;
import com.aliendroid.bootchat.Model.Wallpaper;
import com.aliendroid.bootchat.blackbot.R;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.appodeal.ads.Appodeal;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import com.startapp.sdk.adsbase.StartAppAd;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import static com.aliendroid.bootchat.UtilityPackage.Settings.ADMOB_INTER;
import static com.aliendroid.bootchat.UtilityPackage.Settings.APPODEAL_ID;
import static com.aliendroid.bootchat.UtilityPackage.Settings.COUNTER;
import static com.aliendroid.bootchat.UtilityPackage.Settings.FAN_INTER;
import static com.aliendroid.bootchat.UtilityPackage.Settings.INTERVAL;
import static com.aliendroid.bootchat.UtilityPackage.Settings.INTER_MOPUB;
import static com.aliendroid.bootchat.UtilityPackage.Settings.ON_OF_DATA;
import static com.aliendroid.bootchat.UtilityPackage.Settings.SELECT_ADS;
import static com.aliendroid.bootchat.UtilityPackage.Settings.URL_DATA;

public class WallpaperFragment extends Fragment {

    private TextView txtjdl;
    private ImageView imggbr, imgback, imgnext;
    private Button setwall;
    int pos =0;

    private InterstitialAd mInterstitialAd;
    public static com.facebook.ads.InterstitialAd interstitialAdfb;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_wallpaper, container, false);
        switch (SELECT_ADS) {
            case "ADMOB":
                loadadmobinter();
                break;
            case "FACEBOOK":
                interstitialAdfb = new com.facebook.ads.InterstitialAd(getContext(), FAN_INTER);
                interstitialAdfb.loadAd();
                break;
            case "APPODEAL":
                loadappodealinter();
                break;

        }

        txtjdl = view.findViewById(R.id.txtimgwall);
        imggbr = view.findViewById(R.id.imgwall);
        setwall = view.findViewById(R.id.btwall);

        Glide.with(this).load(SplashActivity.webLists.get(pos).getAvatar_url())
                .centerCrop().into(imggbr);
        txtjdl.setText(SplashActivity.webLists.get(pos).getHtml_url());
        setHasOptionsMenu(true);

        imgback = view.findViewById(R.id.imgback);
        imgnext= view.findViewById(R.id.imgnext);

        setwall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bitmap bitmap = ((BitmapDrawable)imggbr.getDrawable()).getBitmap();
                try {
                    WallpaperManager myWallpaperManager
                            = WallpaperManager.getInstance(getActivity().getApplicationContext());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        myWallpaperManager.setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM);
                    }
                    Toast.makeText(getActivity(), "Wallpaper set Home Screen",
                            Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    Toast.makeText(getActivity(),
                            "Error setting wallpaper", Toast.LENGTH_SHORT)
                            .show();
                }

            }
        });

        imgback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pos--;
                pos = (pos +SplashActivity.webLists.size()) % SplashActivity.webLists.size();
                Glide.with(getActivity()).load(SplashActivity.webLists.get(pos).getAvatar_url())
                        .centerCrop().into(imggbr);
                txtjdl.setText(SplashActivity.webLists.get(pos).getHtml_url());
                if (COUNTER>Integer.parseInt(INTERVAL)){
                    switch (SELECT_ADS) {
                        case "ADMOB":
                            final ProgressDialog progressDialog = new ProgressDialog(getActivity());
                            progressDialog.setMessage("Loading ads...");
                            progressDialog.setCancelable(true);
                            progressDialog.show();
                            new CountDownTimer(3000, 1000) {
                                @Override
                                public void onFinish() {
                                    progressDialog.dismiss();
                                    tampiladmobinter();
                                }

                                @Override
                                public void onTick(long millisUntilFinished) {

                                }
                            }.start();
                            break;
                        case "FACEBOOK":
                            if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                                interstitialAdfb.loadAd();
                            } else {
                                interstitialAdfb.show();
                                interstitialAdfb.loadAd();
                            }
                            break;

                        case "STARTAPP":
                            StartAppAd.showAd(getActivity());
                            break;

                        case "APPODEAL":
                            tampilappodealinter();
                            break;
                    }
                    COUNTER=0;
                } else {
                    switch (SELECT_ADS) {
                        case "ADMOB":
                            loadadmobinter();
                            break;
                        case "FACEBOOK":
                            if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                                assert interstitialAdfb != null;
                                interstitialAdfb.loadAd();
                            }
                            break;
                        case "APPODEAL":
                            loadappodealinter();
                            break;

                    }
                    COUNTER++;
                }

            }
        });

        imgnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pos++;
                pos = pos % SplashActivity.webLists.size();
                Glide.with(getActivity()).load(SplashActivity.webLists.get(pos).getAvatar_url())
                        .centerCrop().into(imggbr);
                txtjdl.setText(SplashActivity.webLists.get(pos).getHtml_url());
                if (COUNTER>Integer.parseInt(INTERVAL)){
                    switch (SELECT_ADS) {
                        case "ADMOB":
                            final ProgressDialog progressDialog = new ProgressDialog(getActivity());
                            progressDialog.setMessage("Loading ads...");
                            progressDialog.setCancelable(true);
                            progressDialog.show();
                            new CountDownTimer(3000, 1000) {
                                @Override
                                public void onFinish() {
                                    progressDialog.dismiss();
                                   tampiladmobinter();
                                }

                                @Override
                                public void onTick(long millisUntilFinished) {

                                }
                            }.start();
                            break;
                        case "FACEBOOK":
                            if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                                interstitialAdfb.loadAd();
                            } else {
                                interstitialAdfb.show();
                                interstitialAdfb.loadAd();
                            }
                            break;

                        case "STARTAPP":
                            StartAppAd.showAd(getActivity());
                            break;

                        case "APPODEAL":
                            tampilappodealinter();
                            break;
                    }
                    COUNTER=0;
                } else {
                    switch (SELECT_ADS) {
                        case "ADMOB":
                            loadadmobinter();
                            break;
                        case "FACEBOOK":
                            if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                                assert interstitialAdfb != null;
                                interstitialAdfb.loadAd();
                            }
                            break;
                        case "APPODEAL":
                            loadappodealinter();
                            break;

                    }
                    COUNTER++;
                }
            }
        });
        return view;
    }

    private void tampilappodealinter() {
        Appodeal.isLoaded(Appodeal.INTERSTITIAL);
        Appodeal.show(getActivity(), Appodeal.INTERSTITIAL);
    }

    private void loadappodealinter() {
        Appodeal.initialize(getActivity(), APPODEAL_ID, Appodeal.INTERSTITIAL);
        Appodeal.cache(getActivity(), Appodeal.INTERSTITIAL);
        Appodeal.getPredictedEcpm(Appodeal.INTERSTITIAL);
    }



    private void loadadmobinter() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load((Activity)getContext(),ADMOB_INTER, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                mInterstitialAd = interstitialAd;
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                mInterstitialAd = null;
            }
        });
    }


    private void tampiladmobinter() {
        if (mInterstitialAd != null) {
            mInterstitialAd.show ((Activity)getContext());
        } else {
            StartAppAd.showAd((Activity)getContext());
        }
    }


}