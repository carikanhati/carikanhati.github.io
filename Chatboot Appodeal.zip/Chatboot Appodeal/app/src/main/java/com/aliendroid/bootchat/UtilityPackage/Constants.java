package com.aliendroid.bootchat.UtilityPackage;

public class Constants {

    public static String USER = "user";
    public static String BOT = "bot";

    public static String SHARED_PREFERENCES = "user_settings";
    public static String WAS_SPEECH_ALLOWED = "was_speech_allowed";

}
