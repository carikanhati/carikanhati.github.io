package com.aliendroid.bootchat.Model;

public class Video {

    public int id;
    public String gambar_url;
    public String video_url;
    public String judul_vid;
    public String des_vid;

    public Video() {

    }

    public int getId() {
        return id;
    }

    public String getJudul_url() {
        return judul_vid;
    }
    public String getDes_vid() {
        return des_vid;
    }

    public String getGambar_url() {
        return gambar_url;
    }

    public String getVideo_url() {
        return video_url;
    }

}
