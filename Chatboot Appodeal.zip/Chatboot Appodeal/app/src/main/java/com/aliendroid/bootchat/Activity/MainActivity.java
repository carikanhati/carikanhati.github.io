package com.aliendroid.bootchat.Activity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Message;
import android.provider.ContactsContract;
import android.speech.tts.TextToSpeech;
import androidx.annotation.NonNull;

import com.aliendroid.bootchat.blackbot.R;
import com.appodeal.ads.Appodeal;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.ItemTouchHelper;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.aliendroid.bootchat.Adapters.MessageAdapter;
import com.aliendroid.bootchat.Contract.MessageContract;
import com.aliendroid.bootchat.DBHelper.MessageDBHelper;
import com.aliendroid.bootchat.DataTypes.MessageData;
import com.aliendroid.bootchat.UtilityPackage.Constants;

import com.startapp.sdk.adsbase.StartAppAd;

import org.alicebot.ab.AIMLProcessor;
import org.alicebot.ab.Bot;
import org.alicebot.ab.Chat;
import org.alicebot.ab.Graphmaster;
import org.alicebot.ab.MagicBooleans;
import org.alicebot.ab.MagicStrings;
import org.alicebot.ab.PCAIMLProcessorExtension;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

import static com.aliendroid.bootchat.Adapters.ContactAdapter.gambar;
import static com.aliendroid.bootchat.Adapters.ContactAdapter.judul;
import static com.aliendroid.bootchat.UtilityPackage.Settings.ADMOB_INTER;
import static com.aliendroid.bootchat.UtilityPackage.Settings.APPODEAL_ID;
import static com.aliendroid.bootchat.UtilityPackage.Settings.COUNTER;
import static com.aliendroid.bootchat.UtilityPackage.Settings.FAN_INTER;
import static com.aliendroid.bootchat.UtilityPackage.Settings.INTERVAL;
import static com.aliendroid.bootchat.UtilityPackage.Settings.INTER_MOPUB;
import static com.aliendroid.bootchat.UtilityPackage.Settings.LINK_REDIRECT;
import static com.aliendroid.bootchat.UtilityPackage.Settings.SELECT_ADS;
import static com.aliendroid.bootchat.UtilityPackage.Settings.STATUS_APP;

public class MainActivity extends AppCompatActivity {
    private EditText messageInputView;
    private int timePerCharacter;
    private ImageView botSpeechToggle;
    private TextView txtwrite, show_description;
    public Bot bot;
    public static Chat chat;
    private boolean speechAllowed; // the flag for toggling speech engine
    private TextToSpeech textToSpeech;
    private SQLiteDatabase database;
    private MessageAdapter messageAdapter;

    private InterstitialAd mInterstitialAd;
    public static com.facebook.ads.InterstitialAd interstitialAdfb;
    SharedPreferences preferences;
    public static int rd_time =10;
    public static String status_time="Wait for 10 seconds";
    private BottomSheetBehavior bottomSheetBehavior;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (STATUS_APP.equals("1")) {
            String str = LINK_REDIRECT;
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse(str)));
            finish();
        }

        switch (SELECT_ADS) {
            case "ADMOB":
                loadadmobinter();
                break;
            case "FACEBOOK":
                interstitialAdfb = new com.facebook.ads.InterstitialAd(this, FAN_INTER);
                interstitialAdfb.loadAd();
                break;
            case "APPODEAL":
                loadappodealinter();
                break;


        }
        MessageDBHelper messageDBHelper = new MessageDBHelper(this);
        database = messageDBHelper.getWritableDatabase();

        timePerCharacter = 30 + (new Random().nextInt(30)); // 30 - 60
        show_description = findViewById(R.id.show_description);
        messageInputView = findViewById(R.id.message_input_view);
        ImageView messageSendButton = findViewById(R.id.message_send_button);
        txtwrite = findViewById(R.id.txtwrite);
        final ImageView deleteChatMessages = findViewById(R.id.delete_chats);
        botSpeechToggle = findViewById(R.id.bot_speech_toggle);

        ImageView callvide = findViewById(R.id.callvid);
        ImageView imageheader =findViewById(R.id.imageheader);
        Glide.with(this).load(gambar)
                .centerCrop().into(imageheader);
        show_description.setText(judul);

        View bottomSheet = findViewById(R.id.bottom_sheet);
        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        recyclerView.setLayoutManager(linearLayoutManager);
        messageAdapter = new MessageAdapter(this, getAllMessages());
        recyclerView.setAdapter(messageAdapter);

        AssetManager assetManager = getResources().getAssets();
        File cacheDirectory = new File(getCacheDir().toString() + "/kim/bots/alienboot");
        boolean dirMakingSuccessful = cacheDirectory.mkdirs();

        if(dirMakingSuccessful && cacheDirectory.exists()){
            try{
                for(String dir : assetManager.list("alienboot")){
                    File subDirectory = new File(cacheDirectory.getPath() + "/" + dir);
                    subDirectory.mkdirs();
                    for(String file : assetManager.list("alienboot/" + dir)){
                        File f = new File(cacheDirectory.getPath() + "/" + dir + "/" + file);
                        if(!f.exists()){
                            InputStream in;
                            OutputStream out;

                            in = assetManager.open("alienboot/" + dir + "/" + file);
                            out = new FileOutputStream(cacheDirectory.getPath() + "/" + dir + "/" + file);

                            copyFile(in, out);
                            in.close();
                            out.flush();
                            out.close();
                        }
                    }
                }

            } catch(IOException e){
                e.printStackTrace();
                Log.i("alienboot", "IOException occurred when writing from cache!");
            } catch(NullPointerException e){
                Log.i("alienboot", "Nullpoint Exception!");
            }
        }

        final ProgressDialog pd = new ProgressDialog(MainActivity.this);
        pd.setMessage("Initializing Chat...");
        pd.setCanceledOnTouchOutside(false);
        pd.setCancelable(false);

        final Handler handler = new Handler(){
            @Override
            public void dispatchMessage(Message msg) {
                super.dispatchMessage(msg);
                pd.cancel();
            }
        };

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                MagicStrings.root_path = getCacheDir().toString() + "/kim";
                AIMLProcessor.extension = new PCAIMLProcessorExtension();
                bot = new Bot("alienboot", MagicStrings.root_path, "chat");
                chat = new Chat(bot);
                handler.sendMessage(new Message());
            }
        });

        pd.show();
        thread.start();
        messageSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendChatMessage();
                if (COUNTER>Integer.parseInt(INTERVAL)){
                    switch (SELECT_ADS) {
                        case "ADMOB":
                            final ProgressDialog progressDialog = new ProgressDialog(MainActivity.this);
                            progressDialog.setMessage("Loading ads...");
                            progressDialog.setCancelable(true);
                            progressDialog.show();
                            new CountDownTimer(3000, 1000) {
                                @Override
                                public void onFinish() {
                                    progressDialog.dismiss();
                                    tampiladmobinter();
                                }

                                @Override
                                public void onTick(long millisUntilFinished) {

                                }
                            }.start();
                            break;
                        case "FACEBOOK":
                            if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                                interstitialAdfb.loadAd();
                            } else {
                                interstitialAdfb.show();
                                interstitialAdfb.loadAd();
                            }
                            break;

                        case "STARTAPP":
                            StartAppAd.showAd(MainActivity.this);
                            break;
                        case "APPODEAL":
                            tampilappodealinter();
                            break;
                    }
                    COUNTER=0;
                } else {
                    switch (SELECT_ADS) {
                        case "ADMOB":
                            loadadmobinter();
                            break;
                        case "FACEBOOK":
                            if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                                assert interstitialAdfb != null;
                                interstitialAdfb.loadAd();
                            }
                            break;
                        case "APPODEAL":
                            loadappodealinter();
                            break;

                    }
                    COUNTER++;
                }
            }
        });
        textToSpeech = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status == TextToSpeech.SUCCESS){
                    int result = textToSpeech.setLanguage(Locale.getDefault());
                    if(result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED){
                        Toast.makeText(MainActivity.this,
                                "Default Language not recognized!", Toast.LENGTH_SHORT).show();
                        Log.i("alienboot", "Speech Engine not initialized");
                    } else{
                        preferences = getSharedPreferences(Constants.SHARED_PREFERENCES, MODE_PRIVATE);
                        Boolean wasSpeechAllowed = preferences.getBoolean(Constants.WAS_SPEECH_ALLOWED, false);
                        speechAllowed = wasSpeechAllowed;

                        if(wasSpeechAllowed){
                            botSpeechToggle.setImageResource(R.drawable.ic_mute_button);

                        } else{
                            botSpeechToggle.setImageResource(R.drawable.ic_volume_up_button);
                        }

                    }
                }
            }
        });

        deleteChatMessages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteAllChatData();
            }
        });

        botSpeechToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(speechAllowed){
                    speechAllowed = false;
                    botSpeechToggle.setImageResource(R.drawable.ic_volume_up_button);
                } else{
                    speechAllowed = true;
                    botSpeechToggle.setImageResource(R.drawable.ic_mute_button);
                }
                preferences.edit().putBoolean(Constants.WAS_SPEECH_ALLOWED, speechAllowed).apply();

            }
        });

        callvide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, VideoCallActivity.class);
                startActivity(intent);
                finish();
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
                removeItem((long) viewHolder.itemView.getTag());
            }
        }).attachToRecyclerView(recyclerView);

    }

    private void tampilappodealinter() {
        Appodeal.isLoaded(Appodeal.INTERSTITIAL);
        Appodeal.show(MainActivity.this, Appodeal.INTERSTITIAL);
    }

    private void loadappodealinter() {
        Appodeal.initialize(MainActivity.this, APPODEAL_ID, Appodeal.INTERSTITIAL);
        Appodeal.cache(MainActivity.this, Appodeal.INTERSTITIAL);
        Appodeal.getPredictedEcpm(Appodeal.INTERSTITIAL);
    }



    private void loadadmobinter() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this,ADMOB_INTER, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                mInterstitialAd = interstitialAd;
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                mInterstitialAd = null;
            }
        });
    }


    private void tampiladmobinter() {
        if (mInterstitialAd != null) {
            mInterstitialAd.show(this);
        } else {
            StartAppAd.showAd(this);
        }
    }

    private void removeItem(long id){
        database.delete(MessageContract.MessageEntry.TABLE_NAME,
                MessageContract.MessageEntry._ID + "=" + id,null);
        messageAdapter.swapCursor(getAllMessages());
    }

    // method to delete all the chat data
    private void deleteAllChatData(){
        // ask for user confirmation
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setMessage("Are you sure, You want to delete all the chats?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                database.execSQL("DELETE FROM " + MessageContract.MessageEntry.TABLE_NAME);
                messageAdapter.swapCursor(getAllMessages());

                Toast.makeText(MainActivity.this,
                        "All chats deleted!", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Nopes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // do nothing
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    private Cursor getAllMessages(){
        return database.query(
                MessageContract.MessageEntry.TABLE_NAME,
                null,
                null,
                null,
                null,
                null,
                MessageContract.MessageEntry._ID + " DESC"
        );
    }

    public void sendChatMessage(){
        String message = messageInputView.getText().toString().trim();
        if(message.isEmpty()){
            messageInputView.setError("Can't send empty message!");
            messageInputView.requestFocus();
            return;
        }

        DateFormat dateFormat = new SimpleDateFormat("hh:mm dd/MM/yyyy");
        String timeStamp = dateFormat.format(new Date());

        addMessage(new MessageData(Constants.USER, message, timeStamp));

        if(message.toUpperCase().startsWith("CALL")){
            // calling a phone number as requested by user

            String[] replyForCalling = {
                    "Calling",
                    "Placing a call on",
                    "Definitely, calling",
                    "There we go, calling",
                    "Making a call to",
                    "Ji sir, calling"
            };

            String[] temp = message.split(" ", 2);
            displayBotReply(new MessageData(Constants.BOT, replyForCalling[new Random().nextInt(replyForCalling.length)] + " " + temp[1], timeStamp));
            makeCall(temp[1]);
        } else if(message.toUpperCase().startsWith("OPEN") || message.toUpperCase().startsWith("LAUNCH")){
            // call intent to app, requested by user

            String[] replyForOpeningApp = {
                    "There we go, opening",
                    "Launching",
                    "Opening",
                    "Trying to open",
                    "Trying to launch",
                    "There we go, launching"
            };

            String[] temp = message.split(" ", 2);
            displayBotReply(new MessageData(Constants.BOT, replyForOpeningApp[new Random().nextInt(replyForOpeningApp.length)] + " " + temp[1],timeStamp));
        } else if(message.toUpperCase().startsWith("DELETE") || message.toUpperCase().startsWith("CLEAR")){
            displayBotReply(new MessageData(Constants.BOT,"Okay! I will clear up everything for you!", timeStamp));
        } else if(message.toUpperCase().contains("JOKE")){

            String[] replyForJokes = {
                    "Jokes coming right up...",
                    "Processing a hot'n'fresh joke, right for you!",
                    "There you go...",
                    "This might make you laugh...",
                    "My jokes are still in alpha, Hopefully soon they'll get beta, till then...",
                    "Jokes are my another speciality, there you go...",
                    "Jokes, you ask? This might make you laugh...",
                    "Trying to make you laugh...",
                    "You might find this funny...",
                    "Enjoy your joke..."
            };

            displayBotReply(new MessageData(Constants.BOT, replyForJokes[new Random().nextInt(replyForJokes.length)] + "\n" + mainFunction(message), timeStamp));

        } else{
            // chat with bot - save the reply from the bot
            String botReply = mainFunction(message);
            if(botReply.trim().isEmpty()){
                botReply = mainFunction("UDC");
            }
            displayBotReply(new MessageData(Constants.BOT, botReply,timeStamp));
        }

        messageInputView.setText("");

    }

    private void displayBotReply(final MessageData messageData){
        txtwrite.setVisibility(View.VISIBLE);
        final String message = messageData.getMessage();
        int lengthOfMessage = message.length();
        int timeToWriteInMillis = lengthOfMessage*timePerCharacter; // each character taking 10ms to write
        if(timeToWriteInMillis > 3000){timeToWriteInMillis = 3000;} // not letting go beyond 3 secs
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                txtwrite.setVisibility(View.GONE);
                addMessage(messageData);
                if(messageData.getMessage().equals("Okay! I will clear up everything for you!")){
                    deleteAllChatData();
                }
                if(speechAllowed){
                    textToSpeech.setSpeechRate(0.9f);
                    textToSpeech.setPitch(1f);

                    textToSpeech.speak(message, TextToSpeech.QUEUE_FLUSH, null);
                }
            }
        }, timeToWriteInMillis); // the delay is according to the length of message

    }

    private void addMessage(MessageData messageData){
        String sender = messageData.getSender();
        String message = messageData.getMessage();
        String timestamp = messageData.getTimeStamp();

        ContentValues contentValues = new ContentValues();
        contentValues.put(MessageContract.MessageEntry.COLUMN_SENDER, sender);
        contentValues.put(MessageContract.MessageEntry.COLUMN_MESSAGE, message);
        contentValues.put(MessageContract.MessageEntry.COLUMN_TIMESTAMP, timestamp);

        database.insert(MessageContract.MessageEntry.TABLE_NAME, null, contentValues);
        messageAdapter.swapCursor(getAllMessages());
    }
    private void copyFile(InputStream in, OutputStream out) throws IOException {
        byte[] buffer = new byte[1024];
        int read;
        while((read = in.read(buffer)) != -1){
            out.write(buffer, 0, read);
        }
    }

    public static String mainFunction (String args) {
        MagicBooleans.trace_mode = false;
        Graphmaster.enableShortCuts = true;
        return chat.multisentenceRespond(args);
    }

    public String getNumber(String name, Context context){

        String number = "";
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] projection = new String[] {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER};

        Cursor people = context.getContentResolver().query(uri, projection, null, null, null);
        if(people == null){
            return number;
        }

        int indexName = people.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
        int indexNumber = people.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);

        people.moveToFirst();
        do {
            String Name   = people.getString(indexName);
            String Number = people.getString(indexNumber);
            if(Name.equalsIgnoreCase(name)){return Number.replace("-", "");}
        } while (people.moveToNext());

        people.close();

        return number;
    }

    private void makeCall(String name){
        try {
            String number;
            if(name.matches("[0-9]+") && name.length() > 2){
                // string only contains number
                number = name;
            } else{
                number = getNumber(name,MainActivity.this);
            }
            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + number));
            startActivity(callIntent);
        }catch (SecurityException e){
            Toast.makeText(this,"Calling Permission - DENIED!",Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onBackPressed()
    {
        database.execSQL("DELETE FROM " + MessageContract.MessageEntry.TABLE_NAME);
        messageAdapter.swapCursor(getAllMessages());
        finish();
    }


    public void onDestroy(){
        super.onDestroy();
        database.execSQL("DELETE FROM " + MessageContract.MessageEntry.TABLE_NAME);
        messageAdapter.swapCursor(getAllMessages());
    }

}
