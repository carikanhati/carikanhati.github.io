package com.aliendroid.bootchat.Activity;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.aliendroid.bootchat.UtilityPackage.Settings;
import com.aliendroid.bootchat.blackbot.BuildConfig;
import com.aliendroid.bootchat.blackbot.R;
import com.appodeal.ads.Appodeal;
import com.bumptech.glide.Glide;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;

import com.startapp.sdk.adsbase.StartAppAd;

import de.hdodenhof.circleimageview.CircleImageView;

import static com.aliendroid.bootchat.Adapters.ContactAdapter.gambar;
import static com.aliendroid.bootchat.Adapters.ContactAdapter.judul;
import static com.aliendroid.bootchat.Adapters.ContactAdapter.posisi;
import static com.aliendroid.bootchat.UtilityPackage.Settings.ADMOB_INTER;
import static com.aliendroid.bootchat.UtilityPackage.Settings.APPODEAL_ID;
import static com.aliendroid.bootchat.UtilityPackage.Settings.COUNTER;
import static com.aliendroid.bootchat.UtilityPackage.Settings.FAN_INTER;
import static com.aliendroid.bootchat.UtilityPackage.Settings.INTERVAL;
import static com.aliendroid.bootchat.UtilityPackage.Settings.INTER_MOPUB;
import static com.aliendroid.bootchat.UtilityPackage.Settings.SELECT_ADS;

public class VideoCallActivity extends AppCompatActivity implements SurfaceHolder.Callback {
    MediaPlayer mp;
    Camera camera;
    SurfaceView surfaceView,surfaceView2 ;
    SurfaceHolder surfaceHolder;
    VideoView videoView;

    private TextView calling, nameuser;
    private ImageView  adduser;
    private CircleImageView imguser;

    private InterstitialAd mInterstitialAd;
    public static com.facebook.ads.InterstitialAd interstitialAdfb;
    private RelativeLayout cancel, terima, pesan, tolak;
    Handler handler;

    private LinearLayout atas, bawah;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tele_video_call);
        switch (SELECT_ADS) {
            case "ADMOB":
                loadadmobinter();
                break;
            case "FACEBOOK":
                interstitialAdfb = new com.facebook.ads.InterstitialAd(this, FAN_INTER);
                interstitialAdfb.loadAd();
                break;
            case "APPODEAL":
                loadappodealinter();
                break;


        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                checkPermission();

            }
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            int LAYOUT_FLAG = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
            WindowManager.LayoutParams mWindowParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    LAYOUT_FLAG, // Overlay over the other apps.
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE    // This flag will enable the back key press.
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, // make the window to deliver the focus to the BG window.
                    PixelFormat.TRANSPARENT);
        }

        Uri notification = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        mp = MediaPlayer.create(this, R.raw.ringing_tone);
        mp.start();
        mp.setLooping(true);

        atas = findViewById(R.id.atas);
        bawah = findViewById(R.id.bawah);
        videoView = findViewById(R.id.videoView);
        String uriPath = posisi;
        if (Settings.ON_OF_DATA.equals("1")){
            Uri uri = Uri.parse(uriPath);
            videoView.setVideoURI(uri);
            videoView.requestFocus();
        } else if (Settings.ON_OF_DATA.equals("0")){
            if (uriPath.startsWith("http")) {
                Uri uri = Uri.parse(uriPath);
                videoView.setVideoURI(uri);
                videoView.requestFocus();
            } else {
                String fileName = "android.resource://"+  BuildConfig.APPLICATION_ID + "/raw/"+posisi;
                videoView.setVideoURI(Uri.parse(fileName));
                videoView.requestFocus();
            }

        }

        surfaceView = findViewById(R.id.surfaceView);
        surfaceView2 = findViewById(R.id.surfaceView2);
        surfaceView2.setVisibility(View.GONE);
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);
        surfaceHolder.setFormat(PixelFormat.OPAQUE);
        surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);
        handler = new Handler() ;


        calling = findViewById(R.id.txtcall);
        nameuser = findViewById(R.id.txtname);
        imguser = findViewById(R.id.imguser);
        adduser = findViewById(R.id.adduser);
        adduser.setVisibility(View.INVISIBLE);
        cancel = findViewById(R.id.layclose2);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VideoCallActivity.this, MenuActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                    switch (SELECT_ADS) {
                        case "ADMOB":
                                    tampiladmobinter();
                            break;
                        case "FACEBOOK":
                            if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                                interstitialAdfb.loadAd();
                            } else {
                                interstitialAdfb.show();
                                interstitialAdfb.loadAd();
                            }
                            break;

                        case "STARTAPP":
                            StartAppAd.showAd(VideoCallActivity.this);
                            break;

                        case "APPODEAL":
                            tampilappodealinter();
                            break;
                    }
            }
        });

        pesan = findViewById(R.id.laypesan);
        pesan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VideoCallActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
                mp.stop();

            }
        });

        tolak = findViewById(R.id.layclose);
        tolak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(VideoCallActivity.this, MenuActivity.class);
                startActivity(intent);
                finish();
                mp.stop();
                switch (SELECT_ADS) {
                    case "ADMOB":
                        tampiladmobinter();
                        break;
                    case "FACEBOOK":
                        if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                            interstitialAdfb.loadAd();
                        } else {
                            interstitialAdfb.show();
                            interstitialAdfb.loadAd();
                        }
                        break;

                    case "STARTAPP":
                        StartAppAd.showAd(VideoCallActivity.this);
                        break;

                    case "APPODEAL":
                        tampilappodealinter();
                        break;
                }
            }
        });

        terima = findViewById(R.id.layterima);
        terima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mp.stop();
                calling.setVisibility(View.GONE);
                nameuser.setVisibility(View.GONE);
                imguser.setVisibility(View.GONE);
                adduser.setVisibility(View.VISIBLE);
                surfaceView.setVisibility(View.GONE);
                surfaceView2.setVisibility(View.VISIBLE);
                surfaceHolder = surfaceView2.getHolder();
                surfaceHolder.addCallback(VideoCallActivity.this);
                surfaceHolder.setFormat(PixelFormat.OPAQUE);
                surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);

                videoView.start();
                atas.setVisibility(View.GONE);
                bawah.setVisibility(View.VISIBLE);
                tolak.setVisibility(View.VISIBLE);

            }
        });


        /** Creates a count down timer, which will be expired after 5000 milliseconds */
        new CountDownTimer(10000, 1000) {

            /** This method will be invoked on finishing or expiring the timer */
            @Override
            public void onFinish() {
                mp.stop();
                calling.setVisibility(View.GONE);
                nameuser.setVisibility(View.GONE);
                imguser.setVisibility(View.GONE);
                adduser.setVisibility(View.VISIBLE);
                surfaceView.setVisibility(View.GONE);
                surfaceView2.setVisibility(View.VISIBLE);
                surfaceHolder = surfaceView2.getHolder();
                surfaceHolder.addCallback(VideoCallActivity.this);
                surfaceHolder.setFormat(PixelFormat.OPAQUE);
                surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);

                videoView.start();
                atas.setVisibility(View.GONE);
                bawah.setVisibility(View.VISIBLE);
                tolak.setVisibility(View.VISIBLE);
            }

            @Override
            public void onTick(long millisUntilFinished) {

            }
        }.start();

        imguser = findViewById(R.id.imguser);
        Glide.with(this).load(gambar)
                .centerCrop().into(imguser);
        nameuser.setText(judul);

    }

    private void tampilappodealinter() {
        Appodeal.isLoaded(Appodeal.INTERSTITIAL);
        Appodeal.show(VideoCallActivity.this, Appodeal.INTERSTITIAL);
    }

    private void loadappodealinter() {
        Appodeal.initialize(VideoCallActivity.this, APPODEAL_ID, Appodeal.INTERSTITIAL);
        Appodeal.cache(VideoCallActivity.this, Appodeal.INTERSTITIAL);
        Appodeal.getPredictedEcpm(Appodeal.INTERSTITIAL);
    }



    private void loadadmobinter() {
        AdRequest adRequest = new AdRequest.Builder().build();
        InterstitialAd.load(this,ADMOB_INTER, adRequest, new InterstitialAdLoadCallback() {
            @Override
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                mInterstitialAd = interstitialAd;
            }

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                mInterstitialAd = null;
            }
        });
    }


    private void tampiladmobinter() {
        if (mInterstitialAd != null) {
            mInterstitialAd.show(this);
        } else {
            StartAppAd.showAd(this);
        }
    }

    public void surfaceCreated(SurfaceHolder surfaceHolder ) {

        camera = Camera.open(1);
        Camera.Parameters parameters;
        parameters = camera.getParameters();
        camera.setParameters(parameters);
        camera.setDisplayOrientation(90);
        try {
            camera.setPreviewDisplay(surfaceHolder);
            camera.startPreview();
        }catch (Exception e){
        }

    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
        camera.stopPreview();
        camera.release();
        camera=null;

    }
    public void call2(){
        new CountDownTimer(7000, 1000) {
            @Override
            public void onFinish() {
                mp.stop();
                calling.setVisibility(View.GONE);
                nameuser.setVisibility(View.GONE);
                imguser.setVisibility(View.GONE);
                adduser.setVisibility(View.VISIBLE);
                surfaceView.setVisibility(View.GONE);
                surfaceView2.setVisibility(View.VISIBLE);
                videoView.start();
            }
            @Override
            public void onTick(long millisUntilFinished) {
                surfaceHolder = surfaceView2.getHolder();
                surfaceHolder.addCallback(VideoCallActivity.this);
                surfaceHolder.setFormat(PixelFormat.OPAQUE);
                surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_NORMAL);

            }
        }.start();
    }
    public void onBackPressed(){
        mp.stop();
        Intent intent = new Intent(VideoCallActivity.this, MenuActivity.class);
        startActivity(intent);
        finish();
        switch (SELECT_ADS) {
            case "ADMOB":
                tampiladmobinter();
                break;
            case "FACEBOOK":
                if (interstitialAdfb == null || !interstitialAdfb.isAdLoaded()) {
                    interstitialAdfb.loadAd();
                } else {
                    interstitialAdfb.show();
                    interstitialAdfb.loadAd();
                }
                break;

            case "STARTAPP":
                StartAppAd.showAd(VideoCallActivity.this);
                break;

            case "APPODEAL":
                tampilappodealinter();
                break;
        }

    }

    public static int ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE = 5469;
    @TargetApi(Build.VERSION_CODES.M)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE) {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                // You don't have permission
                checkPermission();
            } else {
                // Do as per your logic
            }

        }

    }

    public void checkPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!android.provider.Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, ACTION_MANAGE_OVERLAY_PERMISSION_REQUEST_CODE);
            }
        }
    }


}