package com.aliendroid.bootchat.UtilityPackage;


import com.aliendroid.bootchat.blackbot.BuildConfig;

public class Settings {


    /*
   ON_OF_JSON="0" offline data, get data from json on folder asset
   ON_OF_JSON="1" online data, get data from url json
   */
    public static  String ON_OF_DATA="1";

    /*
    ON_OFF_ADS ="0" offline ads, get data from Settings.java
    ON_OFF_ADS ="1" online ads, get data from url json
     */
    public static String ON_OFF_ADS ="0";

    /*SELECT_ADS="ADMOB"
      SELECT_ADS="FACEBOOK"
      SELECT_ADS="STARTAPP"
      SELECT_ADS="MOPUB"
     */
    public static String SELECT_ADS="APPODEAL";

    /*
     Please upload guide_online.json to your hosting, archive.org, etc
     and fill URL_DATA with your link
      */
    public static final String URL_DATA = "https://tersepona.github.io/json/8_addison.json";


      /*Admob ID
    for admobappid please check string.xml
    replace  <string name="admobappid">ca-app-pub-3940256099942544~3347511713</string>
    with your id
     */

    public static String APPODEAL_ID = "1512bf47cc7a76fa4555d64c0301a3b87b9839e236b6a5ad";

    public static String ADMOB_INTER = "ca-app-pub-3940256099942544/1033173712";
    public static String ADMOB_OPENADS = "ca-app-pub-3940256099942544/1033173712";
    public static String ADMOB_BANNER = "ca-app-pub-3940256099942544/6300978111";

    /*
    STATUS_APP = "0" must set 0 if your app still live on playstore
    and STATUS_APP = "1" if your app "suspend"
    fill LINK_REDIRECT with new link app
    */
    public static String STATUS_APP = "0";
    public static String LINK_REDIRECT = "https://play.google.com/store/apps/details?id=com.ad.tesiqkepribadia&hl=en";

    /*
   Interval for Intertitial ads
    */
    public static String INTERVAL = "3";
    public static String INTERVAL2 = "2";

    /*
      ID starapp
       */
    public static String STARAPPID="123456789";

    /*
    ID Facebook Audience Network
    */
    public static String FAN_INTER="YOUR_PLACEMENT_ID";
    public static String FAN_BANNER="YOUR_PLACEMENT_ID";
    /*
     public static boolean TESTMODE_FAN = true; for testmode
    public static boolean TESTMODE_FAN = false; if app ready to publish
   */
    public static  boolean TESTMODE_FAN = true;

    /*
    ID Mopub
    */
    public static String BANNER_MOPUB = "b195f8dd8ded45fe847ad89ed1d016da" ;
    public static String INTER_MOPUB = "24534e1901884e398f1253216226017e" ;


    public static String Privacy_police="file:///android_asset/privacy_policy.html";

    /*
    fill packagename on alienchatbot.json with your applicationId
    must be same, this method for anti-clone
     */
    public static String KEY_PACK = BuildConfig.APPLICATION_ID;

    public static int COUNTER =0;
}

