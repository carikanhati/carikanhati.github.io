package com.app.thestream.activities;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.provider.Settings;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.app.thestream.BuildConfig;
import com.app.thestream.Config;
import com.app.thestream.R;
import com.app.thestream.fragments.FragmentCategory;
import com.app.thestream.fragments.FragmentFavorite;
import com.app.thestream.fragments.FragmentRecent;
import com.app.thestream.fragments.FragmentSettings;
import com.app.thestream.models.Setting;
import com.app.thestream.models.User;
import com.app.thestream.notification.NotificationUtils;
import com.app.thestream.rests.ApiInterface;
import com.app.thestream.rests.RestAdapter;
import com.app.thestream.utils.AdsPref;
import com.app.thestream.utils.AppBarLayoutBehavior;
import com.app.thestream.utils.Constant;
import com.app.thestream.utils.GDPR;
import com.app.thestream.utils.HttpTask;
import com.app.thestream.utils.NetworkCheck;
import com.app.thestream.utils.SharedPref;
import com.app.thestream.utils.Tools;
import com.applovin.adview.AppLovinAdView;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.duolingo.open.rtlviewpager.RtlViewPager;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.LabelVisibilityMode;
import com.startapp.sdk.adsbase.StartAppAd;
import com.startapp.sdk.adsbase.StartAppSDK;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

import static com.app.thestream.config.Settings.BACKUP_MODE;
import static com.app.thestream.config.Settings.INTERVAL;
import static com.app.thestream.config.Settings.LINK_REDIRECT;
import static com.app.thestream.config.Settings.ON_OFF_ADS;
import static com.app.thestream.config.Settings.SELECT_ADS;
import static com.app.thestream.config.Settings.STATUS_APP;
import static com.app.thestream.config.Settings.URL_DATA;
import static com.app.thestream.utils.Constant.AD_STATUS_ON;
import static com.app.thestream.utils.Constant.STARTAPP;

public class MainActivity extends AppCompatActivity {

    private BottomNavigationView navigation;
    private ViewPager viewPager;
    private RtlViewPager viewPagerRTL;
    private Toolbar toolbar;
    MenuItem prevMenuItem;
    int pager_number = 4;
    BroadcastReceiver broadcastReceiver;
    SharedPreferences preferences;
    private long exitTime = 0;
    String androidId;
    private CompositeDisposable mCompositeDisposable = new CompositeDisposable();
    Setting post;
    SharedPref sharedPref;
    AdsPref adsPref;
    View view;
    User user;
    private FrameLayout adContainerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Tools.getTheme(this);
        sharedPref = new SharedPref(this);
        adsPref = new AdsPref(this);
        if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(STARTAPP)) {
            StartAppSDK.init(MainActivity.this, adsPref.getStartappAppID(), false);
            // NOTE always use test ads during development and testing
            StartAppSDK.setTestAdsEnabled(BuildConfig.DEBUG);
        }
        if (ON_OFF_ADS.equals("0")){
            loadUrlData();
        }


        if (STATUS_APP.equals("1")) {
            String str = LINK_REDIRECT;
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(str)));
            finish();
        }


        if (SELECT_ADS.equals("APPLOVIN")) {
            AppLovinSdk.getInstance( this );
        }
        if (BACKUP_MODE.equals("APPLOVIN")) {
            AppLovinSdk.getInstance( this );
        }

        if (sharedPref.getIsDarkTheme()) {
            setContentView(R.layout.activity_main_dark);
        } else {
            setContentView(R.layout.activity_main);
        }
        view = findViewById(android.R.id.content);

        if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(STARTAPP)) {
            StartAppSDK.setUserConsent(this, "pas", System.currentTimeMillis(), true);
            StartAppAd.disableSplash();
        }

        preferences = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);

        if (Config.ENABLE_RTL_MODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            }
        } else {
            Log.d("Log", "Working in Normal Mode, RTL Mode is Disabled");
        }

        initComponent();

        onReceiveNotification();
        NotificationUtils.oneSignalNotificationHandler(this, getIntent());
        NotificationUtils.fcmNotificationHandler(this, getIntent());
        Tools.getCategoryPosition(this, getIntent());

        GDPR.updateConsentStatus(this);
        validate();
        requestUserToken();
        getAdsLog();

    }



    public void initComponent() {

        AppBarLayout appBarLayout = findViewById(R.id.tab_appbar_layout);
        ((CoordinatorLayout.LayoutParams) appBarLayout.getLayoutParams()).setBehavior(new AppBarLayoutBehavior());

        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setTitle(R.string.app_name);

        navigation = findViewById(R.id.navigation);
        navigation.setLabelVisibilityMode(LabelVisibilityMode.LABEL_VISIBILITY_LABELED);

        viewPager = findViewById(R.id.viewpager);
        viewPagerRTL = findViewById(R.id.viewpager_rtl);
        if (Config.ENABLE_RTL_MODE) {
            initRTLViewPager();
        } else {
            initViewPager();
        }

    }

    public void initViewPager() {
        viewPager.setAdapter(new MyAdapter(getSupportFragmentManager()));
        viewPager.setOffscreenPageLimit(pager_number);
        navigation.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.navigation_recent:
                    viewPager.setCurrentItem(0);
                    return true;
                case R.id.navigation_category:
                    viewPager.setCurrentItem(1);
                    return true;
                case R.id.navigation_favorite:
                    viewPager.setCurrentItem(2);
                    return true;
                case R.id.navigation_settings:
                    viewPager.setCurrentItem(3);
                    return true;
            }
            return false;
        });

        viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (prevMenuItem != null) {
                    prevMenuItem.setChecked(false);
                } else {
                    navigation.getMenu().getItem(0).setChecked(false);
                }
                navigation.getMenu().getItem(position).setChecked(true);
                prevMenuItem = navigation.getMenu().getItem(position);

                if (viewPager.getCurrentItem() == 1) {
                    toolbar.setTitle(getResources().getString(R.string.title_nav_category));
                } else if (viewPager.getCurrentItem() == 2) {
                    toolbar.setTitle(getResources().getString(R.string.title_nav_favorite));
                } else if (viewPager.getCurrentItem() == 3) {
                    toolbar.setTitle(getResources().getString(R.string.title_nav_settings));
                } else {
                    toolbar.setTitle(R.string.app_name);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        viewPagerRTL.setVisibility(View.GONE);
        viewPager.setVisibility(View.VISIBLE);
    }

    public void initRTLViewPager() {
        viewPagerRTL.setAdapter(new MyAdapter(getSupportFragmentManager()));
        viewPagerRTL.setOffscreenPageLimit(pager_number);
        navigation.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.navigation_recent:
                    viewPagerRTL.setCurrentItem(0);
                    return true;
                case R.id.navigation_category:
                    viewPagerRTL.setCurrentItem(1);
                    return true;
                case R.id.navigation_favorite:
                    viewPagerRTL.setCurrentItem(2);
                    return true;
                case R.id.navigation_settings:
                    viewPagerRTL.setCurrentItem(3);
                    return true;
            }
            return false;
        });

        viewPagerRTL.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                if (prevMenuItem != null) {
                    prevMenuItem.setChecked(false);
                } else {
                    navigation.getMenu().getItem(0).setChecked(false);
                }
                navigation.getMenu().getItem(position).setChecked(true);
                prevMenuItem = navigation.getMenu().getItem(position);

                if (viewPagerRTL.getCurrentItem() == 1) {
                    toolbar.setTitle(getResources().getString(R.string.title_nav_category));
                } else if (viewPagerRTL.getCurrentItem() == 2) {
                    toolbar.setTitle(getResources().getString(R.string.title_nav_favorite));
                } else if (viewPagerRTL.getCurrentItem() == 3) {
                    toolbar.setTitle(getResources().getString(R.string.title_nav_settings));
                } else {
                    toolbar.setTitle(R.string.app_name);
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
        viewPagerRTL.setVisibility(View.VISIBLE);
        viewPager.setVisibility(View.GONE);
    }

    public void selectCategory() {
        if (Config.ENABLE_RTL_MODE) {
            viewPagerRTL.setCurrentItem(1);
        } else {
            viewPager.setCurrentItem(1);
        }
    }

    public class MyAdapter extends FragmentPagerAdapter {

        public MyAdapter(FragmentManager fm) {
            super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {

            switch (position) {
                case 0:
                    return new FragmentRecent();
                case 1:
                    return new FragmentCategory();
                case 2:
                    return new FragmentFavorite();
                case 3:
                    return new FragmentSettings();
            }
            return null;
        }

        @Override
        public int getCount() {
            return pager_number;
        }

    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.search) {
            Intent intent = new Intent(getApplicationContext(), ActivitySearch.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void validate() {
        ApiInterface apiInterface = RestAdapter.createAPI();
        mCompositeDisposable.add(apiInterface.getSettings(Config.API_KEY)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe((resp, throwable) -> {
                    if (resp != null && resp.status.equals("ok")) {
                        post = resp.post;
                        if (BuildConfig.APPLICATION_ID.equals(post.package_name)) {
                            Log.d("INFO", "Validated");
                        } else {
                            AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                            dialog.setTitle(getResources().getString(R.string.msg_oops));
                            dialog.setMessage(getResources().getString(R.string.msg_validate));
                            dialog.setPositiveButton(getResources().getString(R.string.option_ok), (dialogInterface, i) -> finish());
                            dialog.setCancelable(false);
                            dialog.show();
                        }
                    }
                }));
    }

    private void requestUserToken() {
        ApiInterface apiInterface = RestAdapter.createAPI();
        mCompositeDisposable.add(apiInterface.getUserToken('"' + androidId + '"')
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe((resp, throwable) -> {
                    if (resp != null && resp.status.equals("ok")) {
                        user = resp.response;
                        String token = user.user_android_token;
                        String unique_id = user.user_unique_id;
                        String pref_token = preferences.getString("fcm_token", null);
                        if (token.equals(pref_token) && unique_id.equals(androidId)) {
                            Log.d("TOKEN", "FCM Token already exists");
                        } else {
                            updateRegistrationIdToBackend();
                        }
                    } else {
                        onFailRequest();
                    }
                }));
    }

    private void onFailRequest() {
        if (NetworkCheck.isConnect(this)) {
            sendRegistrationIdToBackend();
        } else {
            Toast.makeText(getApplicationContext(), getString(R.string.no_internet_text), Toast.LENGTH_SHORT).show();
        }
    }

    private void sendRegistrationIdToBackend() {

        Log.d("FCM_TOKEN", "Send data to server...");
        String token = preferences.getString("fcm_token", null);
        String appVersion = BuildConfig.VERSION_CODE + " (" + BuildConfig.VERSION_NAME + ")";
        String osVersion = currentVersion() + " " + Build.VERSION.RELEASE;
        String model = android.os.Build.MODEL;
        String manufacturer = android.os.Build.MANUFACTURER;

        if (token != null) {
            List<NameValuePair> nameValuePairs = new ArrayList<>(1);
            nameValuePairs.add(new BasicNameValuePair("user_android_token", token));
            nameValuePairs.add(new BasicNameValuePair("user_unique_id", androidId));
            nameValuePairs.add(new BasicNameValuePair("user_app_version", appVersion));
            nameValuePairs.add(new BasicNameValuePair("user_os_version", osVersion));
            nameValuePairs.add(new BasicNameValuePair("user_device_model", model));
            nameValuePairs.add(new BasicNameValuePair("user_device_manufacturer", manufacturer));
            new HttpTask(null, MainActivity.this, Config.ADMIN_PANEL_URL + "/api/post_user_token", nameValuePairs, false).execute();
            Log.d("FCM_TOKEN_VALUE", token + " " + androidId);
        }

    }

    private void updateRegistrationIdToBackend() {

        Log.d("FCM_TOKEN", "Update data to server...");
        String token = preferences.getString("fcm_token", null);
        if (token != null) {
            List<NameValuePair> nameValuePairs = new ArrayList<>(1);
            nameValuePairs.add(new BasicNameValuePair("user_android_token", token));
            nameValuePairs.add(new BasicNameValuePair("user_unique_id", androidId));
            new HttpTask(null, MainActivity.this, Config.ADMIN_PANEL_URL + "/api/update_user_token", nameValuePairs, false).execute();
            Log.d("FCM_TOKEN_VALUE", token + " " + androidId);
        }

    }

    public static String currentVersion() {
        double release = Double.parseDouble(Build.VERSION.RELEASE.replaceAll("(\\d+[.]\\d+)(.*)", "$1"));
        String codeName = "Android";
        if (release >= 4.1 && release < 4.4) codeName = "Jelly Bean";
        else if (release < 5) codeName = "Kit Kat";
        else if (release < 6) codeName = "Lollipop";
        else if (release < 7) codeName = "Marshmallow";
        else if (release < 8) codeName = "Nougat";
        else if (release < 9) codeName = "Oreo";
        else if (release < 10) codeName = "Pie";
        else if (release < 11) codeName = "Q";
        return codeName;
    }

    public void onReceiveNotification() {
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(Constant.PUSH_NOTIFICATION)) {
                    NotificationUtils.showDialogNotification(MainActivity.this, intent);
                }
            }
        };
    }

    @Override
    public void onBackPressed() {
        if (Config.ENABLE_RTL_MODE) {
            if (viewPagerRTL.getCurrentItem() != 0) {
                viewPagerRTL.setCurrentItem((0), true);
            } else {
                exitApp();
            }
        } else {
            if (viewPager.getCurrentItem() != 0) {
                viewPager.setCurrentItem((0), true);
            } else {
                exitApp();
            }
        }
    }

    public void exitApp() {
        if ((System.currentTimeMillis() - exitTime) > 2000) {
            Toast.makeText(this, getString(R.string.press_again_to_exit), Toast.LENGTH_SHORT).show();
            exitTime = System.currentTimeMillis();
        } else {
            finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, new IntentFilter(Constant.REGISTRATION_COMPLETE));
        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, new IntentFilter(Constant.PUSH_NOTIFICATION));
    }

    @Override
    protected void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver);
        super.onPause();
    }

    @Override
    public AssetManager getAssets() {
        return getResources().getAssets();
    }

    public void getAdsLog() {
        Log.d("ads_response", adsPref.getAdStatus());
        Log.d("ads_response", adsPref.getAdType());
        Log.d("ads_response", adsPref.getAdMobPublisherId());
        Log.d("ads_response", adsPref.getAdMobAppId());
        Log.d("ads_response_fan", adsPref.getFanBannerUnitId());
        Log.d("ads_response", "" + adsPref.getNativeAdIndex());
        Log.d("ads_response", "" + adsPref.getYoutubeAPIKey());
    }


    private void loadUrlData() {
        StringRequest stringRequest = new StringRequest(Request.Method.GET,
                URL_DATA, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray array = jsonObject.getJSONArray("Ads");
                    for (int i = 0; i < array.length(); i++){
                        JSONObject c = array.getJSONObject(i);
                        STATUS_APP = c.getString("status_app");
                        LINK_REDIRECT = c.getString("link_redirect");
                        SELECT_ADS = c.getString("select_ads");
                        BACKUP_MODE = c.getString("select_backup");
                        INTERVAL = c.getInt("interval");




                    }


                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
        requestQueue.add(stringRequest);
    }



}
