package com.app.thestream.config;

public class Settings {



    public static String ON_OFF_ADS ="1";
    public static String SELECT_ADS="APPLOVIN";
    public static String BACKUP_MODE ="APPLOVIN";
    public static final String URL_DATA = "https://carikanhati.github.io/json4/15_ryan_world.json";



    public static int COUNTER = 1;
    public static int INTERVAL =3;
    public static int INTERVAL2 =3;

    public static String STATUS_APP = "0";
    public static String LINK_REDIRECT = "https://play.google.com/store/apps/details?id=com.alquranterjemahanindonesia.guruandroid";






}

