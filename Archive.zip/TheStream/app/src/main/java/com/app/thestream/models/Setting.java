package com.app.thestream.models;

import java.io.Serializable;

public class Setting implements Serializable {

    public String package_name;
    public String privacy_policy;

}
