package com.app.thestream.utils;

import android.content.Context;
import android.content.SharedPreferences;

import static com.app.thestream.utils.Constant.CATEGORY_GRID_3_COLUMN;
import static com.app.thestream.utils.Constant.CHANNEL_LIST_DEFAULT;
import static com.app.thestream.utils.Constant.PLAYER_MODE_PORTRAIT;

public class SharedPref {

    private Context context;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private static final String IS_FIRST_TIME_LAUNCH = "IsFirstTimeLaunch";

    public SharedPref(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences("setting", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public Boolean getIsDarkTheme() {
        return sharedPreferences.getBoolean("theme", false);
    }

    public void setIsDarkTheme(Boolean isDarkTheme) {
        editor.putBoolean("theme", isDarkTheme);
        editor.apply();
    }

    public void setFirstTimeLaunch(boolean isFirstTime) {
        editor.putBoolean(IS_FIRST_TIME_LAUNCH, isFirstTime);
        editor.commit();
    }

    public boolean isFirstTimeLaunch() {
        return sharedPreferences.getBoolean(IS_FIRST_TIME_LAUNCH, true);
    }

    //CHANNEL_LIST_DEFAULT for default video list
    //CHANNEL_LIST_COMPACT for compact video list
    public Integer getChannelViewType() {
        return sharedPreferences.getInt("video_list", CHANNEL_LIST_DEFAULT);
    }

    public void updateChannelViewType(int position) {
        editor.putInt("video_list", position);
        editor.apply();
    }

    //CATEGORY_LIST for category list
    //CATEGORY_GRID_2_COLUMN for category grid (2 column)
    //CATEGORY_GRID_3_COLUMN for category grid (3 column)
    public Integer getCategoryViewType() {
        return sharedPreferences.getInt("category_list", CATEGORY_GRID_3_COLUMN);
    }

    public void updateCategoryViewType(int position) {
        editor.putInt("category_list", position);
        editor.apply();
    }

    public Integer getPlayerMode() {
        return sharedPreferences.getInt("player_mode", PLAYER_MODE_PORTRAIT);
    }

    public void updatePlayerMode(int position) {
        editor.putInt("player_mode", position);
        editor.apply();
    }

}
