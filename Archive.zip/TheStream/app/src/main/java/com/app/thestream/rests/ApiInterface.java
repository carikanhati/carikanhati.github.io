package com.app.thestream.rests;

import com.app.thestream.callbacks.CallbackAds;
import com.app.thestream.callbacks.CallbackCategories;
import com.app.thestream.callbacks.CallbackChannel;
import com.app.thestream.callbacks.CallbackChannelDetail;
import com.app.thestream.callbacks.CallbackDetailCategory;
import com.app.thestream.callbacks.CallbackSetting;
import com.app.thestream.callbacks.CallbackUser;

import io.reactivex.Single;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Query;

public interface ApiInterface {

    String CACHE = "Cache-Control: max-age=0";
    String AGENT = "Data-Agent: The Stream";

    @Headers({CACHE, AGENT})
    @GET("api/get_posts")
    Single<CallbackChannel> getRecentChannel(
            @Query("page") int page,
            @Query("count") int count,
            @Query("api_key") String api_key
    );

    @Headers({CACHE, AGENT})
    @GET("api/get_category_posts")
    Single<CallbackDetailCategory> getChannelByCategory(
            @Query("id") int id,
            @Query("page") int page,
            @Query("count") int count,
            @Query("api_key") String api_key
    );

    @Headers({CACHE, AGENT})
    @GET("api/get_category_index")
    Single<CallbackCategories> getAllCategories(
            @Query("api_key") String api_key
    );

    @Headers({CACHE, AGENT})
    @GET("api/get_search_results")
    Single<CallbackChannel> getSearchPosts(
            @Query("search") String search,
            @Query("count") int count,
            @Query("api_key") String api_key
    );

    @Headers({CACHE, AGENT})
    @GET("api/get_post_detail")
    Single<CallbackChannelDetail> getChannelDetail(
            @Query("id") String id
    );

    @Headers({CACHE, AGENT})
    @GET("api/get_user_token")
    Single<CallbackUser> getUserToken(
            @Query("user_unique_id") String user_unique_id
    );

    @Headers({CACHE, AGENT})
    @GET("api/get_settings")
    Single<CallbackSetting> getSettings(
            @Query("api_key") String api_key
    );

    @Headers({CACHE, AGENT})
    @GET("api/get_ads")
    Single<CallbackAds> getAds(
            @Query("api_key") String api_key
    );

}
