package com.app.thestream.callbacks;

import com.app.thestream.models.Setting;

public class CallbackSetting {

    public String status;
    public Setting post = null;

}
