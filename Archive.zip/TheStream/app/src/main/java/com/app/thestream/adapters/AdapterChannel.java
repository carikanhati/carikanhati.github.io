package com.app.thestream.adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import com.app.thestream.BuildConfig;
import com.app.thestream.Config;
import com.app.thestream.R;
import com.app.thestream.models.Channel;
import com.app.thestream.utils.AdsPref;
import com.app.thestream.utils.Constant;
import com.app.thestream.utils.NativeTemplateStyle;
import com.app.thestream.utils.SharedPref;
import com.app.thestream.utils.TemplateView;
import com.app.thestream.utils.Tools;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.formats.MediaView;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.ads.nativead.NativeAdDetails;
import com.startapp.sdk.ads.nativead.NativeAdPreferences;
import com.startapp.sdk.ads.nativead.StartAppNativeAd;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;

import java.util.ArrayList;
import java.util.List;

import static com.app.thestream.utils.Constant.ADMOB;
import static com.app.thestream.utils.Constant.AD_STATUS_ON;
import static com.app.thestream.utils.Constant.CHANNEL_GRID_2_COLUMN;
import static com.app.thestream.utils.Constant.CHANNEL_GRID_3_COLUMN;
import static com.app.thestream.utils.Constant.CHANNEL_LIST_DEFAULT;
import static com.app.thestream.utils.Constant.FAN;
import static com.app.thestream.utils.Constant.STARTAPP;
import static com.app.thestream.utils.Constant.STARTAPP_IMAGE_MEDIUM;

public class AdapterChannel extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final int VIEW_ITEM = 1;
    private final int VIEW_PROG = 0;

    private List<Object> items;

    private boolean loading;
    private OnLoadMoreListener onLoadMoreListener;

    private Context context;
    private OnItemClickListener mOnItemClickListener;
    private OnItemOverflowClickListener mOnItemOverflowClickListener;
    private boolean scrolling = false;

    private StartAppNativeAd startAppNativeAd;
    private NativeAdDetails nativeAdDetails = null;

    public interface OnItemClickListener {
        void onItemClick(View view, Channel obj, int position);
    }

    public interface OnItemOverflowClickListener {
        void onItemOverflowClick(View view, Channel obj, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mOnItemClickListener = mItemClickListener;
    }

    public void setOnItemOverflowClickListener(final OnItemOverflowClickListener mItemOverflowClickListener) {
        this.mOnItemOverflowClickListener = mItemOverflowClickListener;
    }

    public AdapterChannel(Context context, RecyclerView view, List<Object> items) {
        this.items = items;
        this.context = context;
        lastItemViewDetector(view);
        view.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING) {
                    scrolling = true;
                } else if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    scrolling = false;
                }
                super.onScrollStateChanged(recyclerView, newState);
            }
        });
    }

    public class OriginalViewHolder extends RecyclerView.ViewHolder {

        public TextView channel_name;
        public TextView channel_category;
        public ImageView channel_image;
        public LinearLayout lyt_parent;
        public ImageView overflow;

        TemplateView admob_native_template;
        MediaView admob_media_view;

        private NativeAd nativeAd;
        RelativeLayout lyt_fan_native;
        private NativeAdLayout nativeAdLayout;
        private LinearLayout nativeAdView;

        RelativeLayout lyt_startapp_native;
        ImageView startapp_native_image;
        TextView startapp_native_title;
        TextView startapp_native_description;
        Button startapp_native_button;

        private OriginalViewHolder(View v) {
            super(v);
            channel_name = v.findViewById(R.id.channel_name);
            channel_category = v.findViewById(R.id.channel_category);
            channel_image = v.findViewById(R.id.channel_image);
            lyt_parent = v.findViewById(R.id.lyt_parent);
            overflow = v.findViewById(R.id.overflow);

            //admob native ad
            admob_native_template = v.findViewById(R.id.admob_native_template);
            admob_media_view = v.findViewById(R.id.media_view);

            //fan native ad
            lyt_fan_native = v.findViewById(R.id.lyt_fan_native);
            nativeAdLayout = v.findViewById(R.id.native_ad_container);

            //startapp native ad
            lyt_startapp_native = v.findViewById(R.id.lyt_startapp_native);
            startapp_native_image = v.findViewById(R.id.startapp_native_image);
            startapp_native_title = v.findViewById(R.id.startapp_native_title);
            startapp_native_description = v.findViewById(R.id.startapp_native_description);
            startapp_native_button = v.findViewById(R.id.startapp_native_button);
            startapp_native_button.setOnClickListener(v1 -> itemView.performClick());
        }

        private void bindAdMobNativeAdView() {
            final SharedPref sharedPref = new SharedPref(context);
            final AdsPref adsPref = new AdsPref(context);
            AdLoader adLoader = new AdLoader.Builder(context, adsPref.getAdMobNativeId())
                    .forUnifiedNativeAd(unifiedNativeAd -> {
                        if (sharedPref.getIsDarkTheme()) {
                            ColorDrawable colorDrawable = new ColorDrawable(ContextCompat.getColor(context, R.color.colorBackgroundDark));
                            NativeTemplateStyle styles = new NativeTemplateStyle.Builder().withMainBackgroundColor(colorDrawable).build();
                            admob_native_template.setStyles(styles);
                        } else {
                            ColorDrawable colorDrawable = new ColorDrawable(ContextCompat.getColor(context, R.color.colorBackgroundLight));
                            NativeTemplateStyle styles = new NativeTemplateStyle.Builder().withMainBackgroundColor(colorDrawable).build();
                            admob_native_template.setStyles(styles);
                        }
                        admob_media_view.setImageScaleType(ImageView.ScaleType.CENTER_CROP);
                        admob_native_template.setNativeAd(unifiedNativeAd);
                    }).withAdListener(new AdListener() {
                        @Override
                        public void onAdLoaded() {
                            super.onAdLoaded();
                            if (getAdapterPosition() % adsPref.getNativeAdInterval() == adsPref.getNativeAdIndex()) {
                                admob_native_template.setVisibility(View.VISIBLE);
                            } else {
                                admob_native_template.setVisibility(View.GONE);
                            }
                        }

                        @Override
                        public void onAdFailedToLoad(int errorCode) {
                            admob_native_template.setVisibility(View.GONE);
                        }
                    })
                    .build();
            adLoader.loadAd(Tools.getAdRequest((Activity) context));

        }

        private void bindFanNativeAdView() {
            final AdsPref adsPref = new AdsPref(context);
            final SharedPref sharedPref = new SharedPref(context);
            if (BuildConfig.DEBUG) {
                nativeAd = new NativeAd(context, "IMG_16_9_APP_INSTALL#" + adsPref.getFanNativeUnitId());
            } else {
                nativeAd = new NativeAd(context, adsPref.getFanNativeUnitId());
            }
            NativeAdListener nativeAdListener = new NativeAdListener() {
                @Override
                public void onMediaDownloaded(com.facebook.ads.Ad ad) {

                }

                @Override
                public void onError(com.facebook.ads.Ad ad, AdError adError) {

                }

                @Override
                public void onAdLoaded(com.facebook.ads.Ad ad) {
                    // Race condition, load() called again before last ad was displayed
                    if (getAdapterPosition() % adsPref.getNativeAdInterval() == adsPref.getNativeAdIndex()) {
                        lyt_fan_native.setVisibility(View.VISIBLE);
                        if (nativeAd == null || nativeAd != ad) {
                            return;
                        }
                        // Inflate Native Ad into Container
                        //inflateAd(nativeAd);
                        nativeAd.unregisterView();
                        // Add the Ad view into the ad container.
                        LayoutInflater inflater = LayoutInflater.from(context);
                        // Inflate the Ad view.  The layout referenced should be the one you created in the last step.

                        if (sharedPref.getChannelViewType() == CHANNEL_LIST_DEFAULT) {
                            nativeAdView = (LinearLayout) inflater.inflate(R.layout.gnt_fan_small_template, nativeAdLayout, false);
                        } else {
                            nativeAdView = (LinearLayout) inflater.inflate(R.layout.gnt_fan_big_template, nativeAdLayout, false);
                        }
                        nativeAdLayout.addView(nativeAdView);

                        // Add the AdOptionsView
                        LinearLayout adChoicesContainer = nativeAdView.findViewById(R.id.ad_choices_container);
                        AdOptionsView adOptionsView = new AdOptionsView(context, nativeAd, nativeAdLayout);
                        adChoicesContainer.removeAllViews();
                        adChoicesContainer.addView(adOptionsView, 0);

                        // Create native UI using the ad metadata.
                        TextView nativeAdTitle = nativeAdView.findViewById(R.id.native_ad_title);
                        com.facebook.ads.MediaView nativeAdMedia = nativeAdView.findViewById(R.id.native_ad_media);
                        TextView nativeAdSocialContext = nativeAdView.findViewById(R.id.native_ad_social_context);
                        TextView nativeAdBody = nativeAdView.findViewById(R.id.native_ad_body);
                        TextView sponsoredLabel = nativeAdView.findViewById(R.id.native_ad_sponsored_label);
                        Button nativeAdCallToAction = nativeAdView.findViewById(R.id.native_ad_call_to_action);
                        LinearLayout ad_unit = nativeAdView.findViewById(R.id.ad_unit);

                        // Set the Text.
                        nativeAdTitle.setText(nativeAd.getAdvertiserName());
                        nativeAdBody.setText(nativeAd.getAdBodyText());
                        nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
                        nativeAdCallToAction.setVisibility(nativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
                        nativeAdCallToAction.setText(nativeAd.getAdCallToAction());
                        sponsoredLabel.setText(nativeAd.getSponsoredTranslation());

                        // Create a list of clickable views
                        List<View> clickableViews = new ArrayList<>();
                        clickableViews.add(nativeAdTitle);
                        clickableViews.add(ad_unit);
                        clickableViews.add(nativeAdCallToAction);

                        // Register the Title and CTA button to listen for clicks.
                        nativeAd.registerViewForInteraction(nativeAdView, nativeAdMedia, clickableViews);
                    } else {
                        lyt_fan_native.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onAdClicked(com.facebook.ads.Ad ad) {

                }

                @Override
                public void onLoggingImpression(com.facebook.ads.Ad ad) {

                }
            };

            NativeAd.NativeLoadAdConfig loadAdConfig = nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build();
            nativeAd.loadAd(loadAdConfig);
        }

        private void bindStartAppNativeAdView() {
            startAppNativeAd = new StartAppNativeAd(context);
            final AdsPref adsPref = new AdsPref(context);
            NativeAdPreferences nativePrefs = new NativeAdPreferences()
                    .setAdsNumber(1)
                    .setAutoBitmapDownload(true)
                    .setPrimaryImageSize(STARTAPP_IMAGE_MEDIUM);
            AdEventListener adListener = new AdEventListener() {
                @Override
                public void onReceiveAd(Ad arg0) {
                    if (getAdapterPosition() % adsPref.getNativeAdInterval() == adsPref.getNativeAdIndex()) {
                        ArrayList<NativeAdDetails> nativeAdsList = startAppNativeAd.getNativeAds();
                        if (nativeAdsList.size() > 0) {
                            nativeAdDetails = nativeAdsList.get(0);
                        }
                        if (nativeAdDetails != null) {
                            startapp_native_image.setImageBitmap(nativeAdDetails.getImageBitmap());
                            startapp_native_title.setText(nativeAdDetails.getTitle());
                            startapp_native_description.setText(nativeAdDetails.getDescription());
                            startapp_native_button.setText(nativeAdDetails.isApp() ? "Install" : "Open");
                            nativeAdDetails.registerViewForInteraction(itemView);
                        }
                        lyt_startapp_native.setVisibility(View.VISIBLE);
                    } else {
                        lyt_startapp_native.setVisibility(View.GONE);
                    }
                }

                @Override
                public void onFailedToReceiveAd(Ad arg0) {
                    lyt_startapp_native.setVisibility(View.GONE);
                }
            };
            startAppNativeAd.loadAd(nativePrefs, adListener);
        }

    }

    public static class ProgressViewHolder extends RecyclerView.ViewHolder {
        public ProgressBar progressBar;

        ProgressViewHolder(View v) {
            super(v);
            progressBar = v.findViewById(R.id.loadMore);
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        switch (viewType) {
            case VIEW_ITEM:
                SharedPref sharedPref = new SharedPref(context);
                if (sharedPref.getChannelViewType() == CHANNEL_GRID_2_COLUMN || sharedPref.getChannelViewType() == CHANNEL_GRID_3_COLUMN) {
                    View menuItemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.lsv_item_post_grid, parent, false);
                    return new OriginalViewHolder(menuItemView);
                } else {
                    View menuItemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.lsv_item_post, parent, false);
                    return new OriginalViewHolder(menuItemView);
                }
            case VIEW_PROG:
                // fall through
            default:
                View loadMoreView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_loading, parent, false);
                return new ProgressViewHolder(loadMoreView);
        }
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        int viewType = getItemViewType(position);
        switch (viewType) {
            case VIEW_ITEM:
                final Channel p = (Channel) items.get(position);
                final OriginalViewHolder vItem = (OriginalViewHolder) holder;

                final AdsPref adsPref = new AdsPref(context);
                if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(ADMOB)) {
                    if (!adsPref.getAdMobNativeId().equals("0")) {
                        if (holder.getAdapterPosition() % adsPref.getNativeAdInterval() == adsPref.getNativeAdIndex()) {
                            vItem.bindAdMobNativeAdView();
                        } else {
                            vItem.admob_native_template.setVisibility(View.GONE);
                        }
                    }
                } else if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(FAN)) {
                    if (!adsPref.getFanNativeUnitId().equals("0")) {
                        if (holder.getAdapterPosition() % adsPref.getNativeAdInterval() == adsPref.getNativeAdIndex()) {
                            vItem.bindFanNativeAdView();
                        } else {
                            vItem.lyt_fan_native.setVisibility(View.GONE);
                        }
                    }
                } else if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(STARTAPP)) {
                    if (!adsPref.getStartappAppID().equals("0")) {
                        if (holder.getAdapterPosition() % adsPref.getNativeAdInterval() == adsPref.getNativeAdIndex()) {
                            vItem.bindStartAppNativeAdView();
                        } else {
                            vItem.lyt_startapp_native.setVisibility(View.GONE);
                        }
                    }
                }

                vItem.channel_name.setText(p.channel_name);

                vItem.channel_category.setText(p.category_name);
                if (Config.ENABLE_CHANNEL_LIST_CATEGORY_NAME) {
                    vItem.channel_category.setVisibility(View.VISIBLE);
                } else {
                    vItem.channel_category.setVisibility(View.GONE);
                }

                if (p.channel_type != null && p.channel_type.equals("YOUTUBE")) {
                    Picasso.get()
                            .load(Constant.YOUTUBE_IMG_FRONT + p.video_id + Constant.YOUTUBE_IMG_BACK)
                            .placeholder(R.drawable.ic_thumbnail)
                            .resizeDimen(R.dimen.list_image_width, R.dimen.list_image_height)
                            .centerCrop()
                            .into(vItem.channel_image);
                } else {
                    Picasso.get()
                            .load(Config.ADMIN_PANEL_URL + "/upload/" + p.channel_image.replace(" ", "%20"))
                            .placeholder(R.drawable.ic_thumbnail)
                            .resizeDimen(R.dimen.list_image_width, R.dimen.list_image_height)
                            .centerCrop()
                            .into(vItem.channel_image);
                }

                vItem.lyt_parent.setOnClickListener(view -> {
                    if (mOnItemClickListener != null) {
                        mOnItemClickListener.onItemClick(view, p, position);
                    }
                });

                vItem.overflow.setOnClickListener(view -> {
                    if (mOnItemOverflowClickListener != null) {
                        mOnItemOverflowClickListener.onItemOverflowClick(view, p, position);
                    }
                });

                break;
            case VIEW_PROG:
                //fall through
            default:
                ((ProgressViewHolder) holder).progressBar.setIndeterminate(true);
        }

        if (viewType == VIEW_PROG) {
            StaggeredGridLayoutManager.LayoutParams layoutParams = (StaggeredGridLayoutManager.LayoutParams) holder.itemView.getLayoutParams();
            layoutParams.setFullSpan(true);
        } else {
            StaggeredGridLayoutManager.LayoutParams layoutParams = (StaggeredGridLayoutManager.LayoutParams) holder.itemView.getLayoutParams();
            layoutParams.setFullSpan(false);
        }

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public int getItemViewType(int position) {

        if (items.get(position) != null) {
            return VIEW_ITEM;
        } else {
            return VIEW_PROG;
        }

    }

    public void insertData(List<Channel> items) {
        setLoaded();
        int positionStart = getItemCount();
        int itemCount = items.size();
        this.items.addAll(items);
        notifyItemRangeInserted(positionStart, itemCount);
    }

    public void setLoaded() {
        loading = false;
        for (int i = 0; i < getItemCount(); i++) {
            if (items.get(i) == null) {
                items.remove(i);
                notifyItemRemoved(i);
            }
        }
    }

    public void setLoading() {
        if (getItemCount() != 0) {
            this.items.add(null);
            notifyItemInserted(getItemCount() - 1);
            loading = true;
        }
    }

    public void resetListData() {
        this.items.clear();
        notifyDataSetChanged();
    }

    public void setOnLoadMoreListener(OnLoadMoreListener onLoadMoreListener) {
        this.onLoadMoreListener = onLoadMoreListener;
    }

    private void lastItemViewDetector(RecyclerView recyclerView) {

        if (recyclerView.getLayoutManager() instanceof StaggeredGridLayoutManager) {
            final StaggeredGridLayoutManager layoutManager = (StaggeredGridLayoutManager) recyclerView.getLayoutManager();
            recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                    super.onScrolled(recyclerView, dx, dy);
                    int lastPos = getLastVisibleItem(layoutManager.findLastVisibleItemPositions(null));
                    if (!loading && lastPos == getItemCount() - 1 && onLoadMoreListener != null) {
                        int current_page = getItemCount() / Config.LOAD_MORE;
                        onLoadMoreListener.onLoadMore(current_page);
                        loading = true;
                    }
                }
            });
        }
    }

    public interface OnLoadMoreListener {
        void onLoadMore(int current_page);
    }

    private int getLastVisibleItem(int[] into) {
        int last_idx = into[0];
        for (int i : into) {
            if (last_idx < i) last_idx = i;
        }
        return last_idx;
    }

}