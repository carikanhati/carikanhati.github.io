package com.ultraspeed.vpnultra.activity;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.ultraspeed.vpnultra.R;

public class VipActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vip);
//
    }


}
