package com.ultraspeed.vpnultra.activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.facebook.ads.AdSize;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.material.tabs.TabLayout;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.ViewPager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.widget.LinearLayout;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.ultraspeed.vpnultra.Fragments.FragmentFree;
import com.ultraspeed.vpnultra.Fragments.FragmentVip;
import com.ultraspeed.vpnultra.adapter.TabAdapter;
import com.ultraspeed.vpnultra.R;
import com.ultraspeed.vpnultra.utils.AppData;

import butterknife.ButterKnife;

public class Servers extends AppCompatActivity implements AppData {

    private TabAdapter adapter;
    private TabLayout tabLayout;
    private ViewPager viewPager;


    SharedPreferences prefs;
    Boolean isVip = false;

    LinearLayout ad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servers);
        ButterKnife.bind(this);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbarold);
        toolbar.setTitle("Servers");
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);



        viewPager = (ViewPager) findViewById(R.id.viewPager);
        tabLayout = (TabLayout) findViewById(R.id.tabLayout);
        adapter = new TabAdapter(getSupportFragmentManager());
        adapter.addFragment(new FragmentVip(), "Vip Server");
        adapter.addFragment(new FragmentFree(), "Free Server");
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        prefs = getSharedPreferences(APP_PREFERENCES, Context.MODE_PRIVATE);
        isVip = prefs.getBoolean(IS_VIP, false);

        ad = (LinearLayout) findViewById(R.id.ads);
        if (isVip) {
            ad.setVisibility(LinearLayout.GONE);
        } else {
            if (!isVip) {
                if(getString(R.string.adstype).equalsIgnoreCase("admob")) {
                    AdView mAdView = (AdView) findViewById(R.id.adView);
                    AdRequest adRequest1 = new AdRequest.Builder().build();
                    mAdView.loadAd(adRequest1);
                }else{
                    com.facebook.ads.AdView adView = new com.facebook.ads.AdView(this, getString(R.string.fbbanner), AdSize.BANNER_HEIGHT_50);
                    LinearLayout adContainer = (LinearLayout) findViewById(R.id.banner_container);
                    adContainer.addView(adView);
                    adView.loadAd();
                }
            }
        }

    }
}
