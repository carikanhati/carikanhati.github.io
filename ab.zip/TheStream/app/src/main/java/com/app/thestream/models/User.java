package com.app.thestream.models;

import java.io.Serializable;

public class User implements Serializable {

    public String user_android_token;
    public String user_unique_id;

}
