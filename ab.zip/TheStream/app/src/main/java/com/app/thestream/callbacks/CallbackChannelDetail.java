package com.app.thestream.callbacks;


import com.app.thestream.models.Channel;

import java.util.ArrayList;
import java.util.List;

public class CallbackChannelDetail {

    public String status = "";
    public Channel post = null;
    public List<Channel> suggested = new ArrayList<>();

}