package com.app.thestream.callbacks;

import com.app.thestream.models.Category;

import java.util.ArrayList;
import java.util.List;

public class CallbackCategories {

    public String status = "";
    public int count = -1;
    public List<Category> categories = new ArrayList<>();

}
