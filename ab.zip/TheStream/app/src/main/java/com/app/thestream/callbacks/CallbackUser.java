package com.app.thestream.callbacks;

import com.app.thestream.models.User;

public class CallbackUser {

    public String status = "";
    public User response = null;

}