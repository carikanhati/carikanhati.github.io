package com.app.thestream.activities;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.app.thestream.BuildConfig;
import com.app.thestream.Config;
import com.app.thestream.R;
import com.app.thestream.adapters.AdapterChannel;
import com.app.thestream.config.Settings;
import com.app.thestream.databases.DatabaseHandlerFavorite;
import com.app.thestream.models.Category;
import com.app.thestream.models.Channel;
import com.app.thestream.notification.NotificationUtils;
import com.app.thestream.rests.ApiInterface;
import com.app.thestream.rests.RestAdapter;
import com.app.thestream.utils.AdsPref;
import com.app.thestream.utils.Constant;
import com.app.thestream.utils.ItemOffsetDecoration;
import com.app.thestream.utils.NetworkCheck;
import com.app.thestream.utils.SharedPref;
import com.app.thestream.utils.Tools;
import com.applovin.adview.AppLovinAdView;
import com.applovin.adview.AppLovinInterstitialAd;
import com.applovin.adview.AppLovinInterstitialAdDialog;
import com.applovin.sdk.AppLovinAd;
import com.applovin.sdk.AppLovinAdLoadListener;
import com.applovin.sdk.AppLovinAdSize;
import com.applovin.sdk.AppLovinSdk;
import com.applovin.sdk.AppLovinSdkUtils;
import com.facebook.ads.Ad;
import com.facebook.ads.AdError;
import com.facebook.ads.AdSize;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.startapp.sdk.ads.banner.Banner;
import com.startapp.sdk.ads.banner.BannerListener;
import com.startapp.sdk.adsbase.StartAppAd;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

import static com.app.thestream.Config.API_KEY;
import static com.app.thestream.config.Settings.BACKUP_MODE;
import static com.app.thestream.config.Settings.SELECT_ADS;
import static com.app.thestream.utils.Constant.ADMOB;
import static com.app.thestream.utils.Constant.AD_STATUS_ON;
import static com.app.thestream.utils.Constant.CHANNEL_GRID_2_COLUMN;
import static com.app.thestream.utils.Constant.CHANNEL_GRID_3_COLUMN;
import static com.app.thestream.utils.Constant.CHANNEL_LIST_DEFAULT;
import static com.app.thestream.utils.Constant.FAN;
import static com.app.thestream.utils.Constant.STARTAPP;

public class ActivityCategoryDetail extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AdapterChannel adapterChannel;
    private SwipeRefreshLayout swipeRefreshLayout;
    private ArrayList<Object> feedItems = new ArrayList<>();
    private CompositeDisposable mCompositeDisposable = new CompositeDisposable();
    private int post_total = 0;
    private int failed_page = 0;
    private Category category;
    BroadcastReceiver broadcastReceiver;
    private CharSequence charSequence = null;
    private DatabaseHandlerFavorite databaseHandler;
    private FrameLayout adContainerView;
    private ShimmerFrameLayout lyt_shimmer;
    private AdView adView;
    private com.facebook.ads.AdView fanAdView;
    private InterstitialAd interstitialAd;
    private StartAppAd startAppAd;
    int counter = 1;
    SharedPref sharedPref;
    AdsPref adsPref;
    View view;
    public static AppLovinInterstitialAdDialog interstitialAdlovin;
    public static AppLovinAd loadedAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Tools.getTheme(this);
        setContentView(R.layout.activity_category_details);
        view = findViewById(android.R.id.content);

        if (Config.ENABLE_RTL_MODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            }
        }

        sharedPref = new SharedPref(this);
        adsPref = new AdsPref(this);

        initAdNetwork();

        category = (Category) getIntent().getSerializableExtra(Constant.EXTRA_OBJC);

        lyt_shimmer = findViewById(R.id.shimmer_view_container);
        initShimmerLayout();

        swipeRefreshLayout = findViewById(R.id.swipe_refresh_layout);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorPrimary);

        recyclerView = findViewById(R.id.recyclerView);

        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(getApplicationContext(), R.dimen.grid_space_channel);
        if (sharedPref.getChannelViewType() == CHANNEL_LIST_DEFAULT) {
            recyclerView.setLayoutManager(new StaggeredGridLayoutManager(1, StaggeredGridLayoutManager.VERTICAL));
        } else if (sharedPref.getChannelViewType() == CHANNEL_GRID_2_COLUMN) {
            recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL));
            recyclerView.addItemDecoration(itemDecoration);
        } else if (sharedPref.getChannelViewType() == CHANNEL_GRID_3_COLUMN) {
            recyclerView.setLayoutManager(new StaggeredGridLayoutManager(3, StaggeredGridLayoutManager.VERTICAL));
            recyclerView.addItemDecoration(itemDecoration);
        }

        recyclerView.setHasFixedSize(true);

        //set data and list adapter
        adapterChannel = new AdapterChannel(this, recyclerView, feedItems);
        recyclerView.setAdapter(adapterChannel);

        // on item list clicked
        adapterChannel.setOnItemClickListener((v, obj, position) -> {
            Intent intent = new Intent(getApplicationContext(), ActivityChannelDetail.class);
            intent.putExtra(Constant.EXTRA_OBJC, obj);
            startActivity(intent);

            showAdMobInterstitialAd();
            showStartAppInterstitialAd();
            tampilapplovin();
        });

        // detect when scroll reach bottom
        adapterChannel.setOnLoadMoreListener(current_page -> {
            if (post_total > adapterChannel.getItemCount() && current_page != 0) {
                int next_page = current_page + 1;
                requestAction(next_page);
            } else {
                adapterChannel.setLoaded();
            }
        });

        // on swipe list
        swipeRefreshLayout.setOnRefreshListener(() -> {
            if (mCompositeDisposable != null && !mCompositeDisposable.isDisposed()) {
                mCompositeDisposable.dispose();
                mCompositeDisposable = new CompositeDisposable();
            }
            adapterChannel.resetListData();
            requestAction(1);
        });

        requestAction(1);

        setupToolbar();

        onReceiveNotification();

    }





    public void setupToolbar() {
        final Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        final ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle(category.category_name);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        switch (menuItem.getItemId()) {

            case android.R.id.home:
                onBackPressed();
                return true;

            case R.id.search:
                Intent intent = new Intent(getApplicationContext(), ActivitySearch.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(menuItem);
        }
    }

    private void displayApiResult(final List<Channel> channels) {
        adapterChannel.insertData(channels);
        swipeProgress(false);
        if (channels.size() == 0) {
            showNoItemView(true);
        }
    }

    private void requestPostApi(final int page_no) {
        ApiInterface apiInterface = RestAdapter.createAPI();
        mCompositeDisposable.add(apiInterface.getChannelByCategory(category.cid, page_no, Config.LOAD_MORE, API_KEY)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe((resp, throwable) -> {
                    if (resp != null && resp.status.equals("ok")) {
                        post_total = resp.count_total;
                        displayApiResult(resp.posts);
                        addFavorite();
                    } else {
                        onFailRequest(page_no);
                    }
                }));
    }

    private void onFailRequest(int page_no) {
        failed_page = page_no;
        adapterChannel.setLoaded();
        swipeProgress(false);
        if (NetworkCheck.isConnect(getApplicationContext())) {
            showFailedView(true, getString(R.string.failed_text));
        } else {
            showFailedView(true, getString(R.string.no_internet_text));
        }
    }

    private void requestAction(final int page_no) {
        showFailedView(false, "");
        showNoItemView(false);
        if (page_no == 1) {
            swipeProgress(true);
        } else {
            adapterChannel.setLoading();
        }
        new Handler().postDelayed(() -> requestPostApi(page_no), Constant.DELAY_TIME);
    }

    private void showFailedView(boolean show, String message) {
        View view = findViewById(R.id.lyt_failed);
        ((TextView) findViewById(R.id.failed_message)).setText(message);
        if (show) {
            recyclerView.setVisibility(View.GONE);
            view.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            view.setVisibility(View.GONE);
        }
        findViewById(R.id.failed_retry).setOnClickListener(view1 -> requestAction(failed_page));
    }

    private void showNoItemView(boolean show) {
        View view = findViewById(R.id.lyt_no_item);
        ((TextView) findViewById(R.id.no_item_message)).setText(R.string.no_post_found);
        if (show) {
            recyclerView.setVisibility(View.GONE);
            view.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            view.setVisibility(View.GONE);
        }
    }

    private void swipeProgress(final boolean show) {
        if (!show) {
            swipeRefreshLayout.setRefreshing(show);
            lyt_shimmer.setVisibility(View.GONE);
            lyt_shimmer.stopShimmer();
            return;
        }
        swipeRefreshLayout.post(() -> {
            swipeRefreshLayout.setRefreshing(show);
            lyt_shimmer.setVisibility(View.VISIBLE);
            lyt_shimmer.startShimmer();
        });
    }

    private void initShimmerLayout() {
        View lyt_shimmer_channel_list = findViewById(R.id.lyt_shimmer_channel_list);
        View lyt_shimmer_channel_grid2 = findViewById(R.id.lyt_shimmer_channel_grid2);
        View lyt_shimmer_channel_grid3 = findViewById(R.id.lyt_shimmer_channel_grid3);
        if (sharedPref.getChannelViewType() == CHANNEL_LIST_DEFAULT) {
            lyt_shimmer_channel_list.setVisibility(View.VISIBLE);
            lyt_shimmer_channel_grid2.setVisibility(View.GONE);
            lyt_shimmer_channel_grid3.setVisibility(View.GONE);
        } else if (sharedPref.getChannelViewType() == CHANNEL_GRID_2_COLUMN) {
            lyt_shimmer_channel_list.setVisibility(View.GONE);
            lyt_shimmer_channel_grid2.setVisibility(View.VISIBLE);
            lyt_shimmer_channel_grid3.setVisibility(View.GONE);
        } else if (sharedPref.getChannelViewType() == CHANNEL_GRID_3_COLUMN) {
            lyt_shimmer_channel_list.setVisibility(View.GONE);
            lyt_shimmer_channel_grid2.setVisibility(View.GONE);
            lyt_shimmer_channel_grid3.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        swipeProgress(false);
        if (mCompositeDisposable != null && !mCompositeDisposable.isDisposed()) {
            mCompositeDisposable.clear();
        }
        lyt_shimmer.stopShimmer();
    }

    public void addFavorite() {
        adapterChannel.setOnItemOverflowClickListener((v, obj, position) -> {
            PopupMenu popup = new PopupMenu(getApplicationContext(), v);
            MenuInflater inflater = popup.getMenuInflater();
            inflater.inflate(R.menu.menu_popup, popup.getMenu());
            popup.setOnMenuItemClickListener(item -> {
                switch (item.getItemId()) {
                    case R.id.menu_context_favorite:
                        if (charSequence.equals(getString(R.string.option_set_favorite))) {
                            databaseHandler.AddtoFavorite(new Channel(
                                    obj.category_name,
                                    obj.channel_id,
                                    obj.channel_name,
                                    obj.channel_image,
                                    obj.channel_url,
                                    obj.channel_description,
                                    obj.channel_type,
                                    obj.video_id
                            ));
                            Toast.makeText(getApplicationContext(), getString(R.string.favorite_added), Toast.LENGTH_SHORT).show();

                        } else if (charSequence.equals(getString(R.string.option_unset_favorite))) {
                            databaseHandler.RemoveFav(new Channel(obj.channel_id));
                            Toast.makeText(getApplicationContext(), getString(R.string.favorite_removed), Toast.LENGTH_SHORT).show();
                        }
                        return true;

                    case R.id.menu_context_quick_play:
                        if (obj.channel_type != null && obj.channel_type.equals("YOUTUBE")) {
                            Intent i = new Intent(getApplicationContext(), ActivityYoutubePlayer.class);
                            i.putExtra("id", obj.video_id);
                            startActivity(i);
                        } else {
                            if (obj.channel_url != null && obj.channel_url.startsWith("rtmp://")) {
                                Intent intent = new Intent(getApplicationContext(), ActivityRtmpPlayer.class);
                                intent.putExtra("url", obj.channel_url);
                                startActivity(intent);
                            } else {
                                Intent intent = new Intent(getApplicationContext(), ActivityStreamPlayer.class);
                                intent.putExtra("url", obj.channel_url);
                                startActivity(intent);
                            }
                        }
                        return true;

                    default:
                }
                return false;
            });
            popup.show();

            databaseHandler = new DatabaseHandlerFavorite(this);
            List<Channel> data = databaseHandler.getFavRow(obj.channel_id);
            if (data.size() == 0) {
                popup.getMenu().findItem(R.id.menu_context_favorite).setTitle(R.string.option_set_favorite);
                charSequence = popup.getMenu().findItem(R.id.menu_context_favorite).getTitle();
            } else {
                if (data.get(0).channel_id.equals(obj.channel_id)) {
                    popup.getMenu().findItem(R.id.menu_context_favorite).setTitle(R.string.option_unset_favorite);
                    charSequence = popup.getMenu().findItem(R.id.menu_context_favorite).getTitle();
                }
            }

        });
    }

    public void initAdNetwork() {
        if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(ADMOB)) {
            MobileAds.initialize(ActivityCategoryDetail.this, adsPref.getAdMobAppId());
            loadAdMobBannerAd();
            loadAdMobInterstitialAd();
        } else if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(FAN)) {
            loadFanBannerAd();
        } else if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(STARTAPP)) {
            loadStartAppBannerAd();
            loadStartAppInterstitialAd();
        }
        switch (SELECT_ADS) {
            case "APPLOVIN":
                bannerApplovin();
                loadinterapplovin();
                break;
        }

    }

    private void loadinterapplovin() {
        AppLovinSdk.getInstance(this).getAdService().loadNextAd( AppLovinAdSize.INTERSTITIAL, new AppLovinAdLoadListener()
        {
            @Override
            public void adReceived(AppLovinAd ad)
            {
                loadedAd = ad;
            }

            @Override
            public void failedToReceiveAd(int errorCode)
            {
                // Look at AppLovinErrorCodes.java for list of error codes.
            }
        } );
        interstitialAdlovin = AppLovinInterstitialAd.create( AppLovinSdk.getInstance( this ), this );
    }

    private void bannerApplovin() {
        boolean isTablet = AppLovinSdkUtils.isTablet( this );
        AppLovinAdSize adSize = isTablet ? AppLovinAdSize.LEADER : AppLovinAdSize.BANNER;
        AppLovinAdView adView = new AppLovinAdView( adSize, this );
        adContainerView = findViewById(R.id.admob_banner_view_container);
        adContainerView.addView(adView);
        adView.loadNextAd();
    }

    public void loadAdMobBannerAd() {
        if (!adsPref.getAdMobBannerId().equals("0")) {
            adContainerView = findViewById(R.id.admob_banner_view_container);
            adContainerView.post(() -> {
                adView = new AdView(this);
                adView.setAdUnitId(adsPref.getAdMobBannerId());
                adContainerView.removeAllViews();
                adContainerView.addView(adView);
                adView.setAdSize(Tools.getAdSize(this));
                adView.loadAd(Tools.getAdRequest(this));
                adView.setAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                    }

                    @Override
                    public void onAdFailedToLoad(int error) {
                        adContainerView.setVisibility(View.GONE);
                    }

                    @Override
                    public void onAdLeftApplication() {
                    }

                    @Override
                    public void onAdOpened() {
                    }

                    @Override
                    public void onAdLoaded() {
                        adContainerView.setVisibility(View.VISIBLE);
                    }
                });
            });
        }
    }

    private void loadAdMobInterstitialAd() {
        if (!adsPref.getAdMobInterstitialId().equals("0")) {
            interstitialAd = new InterstitialAd(getApplicationContext());
            interstitialAd.setAdUnitId(adsPref.getAdMobInterstitialId());
            interstitialAd.loadAd(Tools.getAdRequest(ActivityCategoryDetail.this));
            interstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    interstitialAd.loadAd(Tools.getAdRequest(ActivityCategoryDetail.this));
                }

                @Override
                public void onAdFailedToLoad(LoadAdError loadAdError) {
                    switch (BACKUP_MODE) {
                        case "APPLOVIN":
                        AppLovinSdk.getInstance(ActivityCategoryDetail.this).getAdService().loadNextAd(AppLovinAdSize.INTERSTITIAL, new AppLovinAdLoadListener() {
                            @Override
                            public void adReceived(AppLovinAd ad) {
                                loadedAd = ad;
                            }

                            @Override
                            public void failedToReceiveAd(int errorCode) {
                                // Look at AppLovinErrorCodes.java for list of error codes.
                            }
                        });
                        interstitialAdlovin = AppLovinInterstitialAd.create(AppLovinSdk.getInstance(ActivityCategoryDetail.this), ActivityCategoryDetail.this);
                        break;
                    }
                }
            });
        }
    }

    private void showAdMobInterstitialAd() {
        if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(ADMOB)) {
            if (!adsPref.getAdMobInterstitialId().equals("0")) {
                if (interstitialAd != null && interstitialAd.isLoaded()) {
                    if (counter == adsPref.getInterstitialAdInterval()) {
                        interstitialAd.show();
                        counter = 1;
                    } else {
                        counter++;
                        switch (BACKUP_MODE) {
                            case "APPLOVIN":
                                interstitialAdlovin.showAndRender(loadedAd);
                               break;
                        }
                    }
                }
            }
        }
    }


    private void loadFanBannerAd() {
        if (!adsPref.getFanBannerUnitId().equals("0")) {
            if (BuildConfig.DEBUG) {
                fanAdView = new com.facebook.ads.AdView(this, "IMG_16_9_APP_INSTALL#" + adsPref.getFanBannerUnitId(), AdSize.BANNER_HEIGHT_50);
            } else {
                fanAdView = new com.facebook.ads.AdView(this, adsPref.getFanBannerUnitId(), AdSize.BANNER_HEIGHT_50);
            }
            LinearLayout adContainer = findViewById(R.id.fan_banner_view_container);
            // Add the ad view to your activity layout
            adContainer.addView(fanAdView);
            com.facebook.ads.AdListener adListener = new com.facebook.ads.AdListener() {
                @Override
                public void onError(Ad ad, AdError adError) {
                    adContainer.setVisibility(View.GONE);
                }

                @Override
                public void onAdLoaded(Ad ad) {
                    adContainer.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAdClicked(Ad ad) {

                }

                @Override
                public void onLoggingImpression(Ad ad) {

                }
            };
            com.facebook.ads.AdView.AdViewLoadConfig loadAdConfig = fanAdView.buildLoadAdConfig().withAdListener(adListener).build();
            fanAdView.loadAd(loadAdConfig);
        }
    }

    private void loadStartAppBannerAd() {
        if (!adsPref.getStartappAppID().equals("0")) {
            RelativeLayout bannerLayout = findViewById(R.id.startapp_banner_view_container);
            Banner banner = new Banner(this, new BannerListener() {
                @Override
                public void onReceiveAd(View banner) {
                    bannerLayout.setVisibility(View.VISIBLE);
                }

                @Override
                public void onFailedToReceiveAd(View banner) {
                    bannerLayout.setVisibility(View.GONE);
                }

                @Override
                public void onImpression(View view) {

                }

                @Override
                public void onClick(View banner) {
                }
            });
            bannerLayout.addView(banner);
        }
    }

    private void loadStartAppInterstitialAd() {
        if (!adsPref.getStartappAppID().equals("0")) {
            startAppAd = new StartAppAd(this);
        }
    }

    private void showStartAppInterstitialAd() {
        if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(STARTAPP)) {
            if (!adsPref.getStartappAppID().equals("0")) {
                if (counter == adsPref.getInterstitialAdInterval()) {
                    startAppAd.showAd();
                    counter = 1;
                } else {
                    counter++;
                }
            }
        }
    }

    public void onReceiveNotification() {
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(Constant.PUSH_NOTIFICATION)) {
                    NotificationUtils.showDialogNotification(ActivityCategoryDetail.this, intent);
                }
            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, new IntentFilter(Constant.REGISTRATION_COMPLETE));
        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, new IntentFilter(Constant.PUSH_NOTIFICATION));
    }

    @Override
    protected void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver);
        super.onPause();
    }
    private void tampilapplovin() {
        if (Settings.COUNTER >= Settings.INTERVAL) {
            switch (SELECT_ADS) {

                case "APPLOVIN":
                    interstitialAdlovin.showAndRender(loadedAd);
                    break;
            }
            Settings.COUNTER = 1;
        } else {
            switch (SELECT_ADS) {
                case "APPLOVIN":
                    loadinterapplovin();
                    break;


            }
            Settings.COUNTER++;
        }
    }

}



