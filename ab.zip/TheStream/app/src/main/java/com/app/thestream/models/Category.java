package com.app.thestream.models;

import java.io.Serializable;

public class Category implements Serializable {

    public int cid = -1;
    public String category_name;
    public String category_image;

}
