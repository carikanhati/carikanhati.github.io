package com.app.thestream.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.app.thestream.R;
import com.app.thestream.activities.ActivityChannelDetail;
import com.app.thestream.activities.ActivityChannelDetailOffline;
import com.app.thestream.activities.ActivityRtmpPlayer;
import com.app.thestream.activities.ActivityStreamPlayer;
import com.app.thestream.activities.ActivityYoutubePlayer;
import com.app.thestream.adapters.AdapterFavorite;
import com.app.thestream.databases.DatabaseHandlerFavorite;
import com.app.thestream.models.Channel;
import com.app.thestream.utils.Constant;
import com.app.thestream.utils.ItemOffsetDecoration;
import com.app.thestream.utils.NetworkCheck;
import com.app.thestream.utils.SharedPref;

import java.util.ArrayList;
import java.util.List;

import static com.app.thestream.utils.Constant.CHANNEL_GRID_2_COLUMN;
import static com.app.thestream.utils.Constant.CHANNEL_GRID_3_COLUMN;
import static com.app.thestream.utils.Constant.CHANNEL_LIST_DEFAULT;

public class FragmentFavorite extends Fragment {

    private List<Channel> data = new ArrayList<>();
    View root_view, parent_view;
    AdapterFavorite adapterPostList;
    DatabaseHandlerFavorite databaseHandler;
    RecyclerView recyclerView;
    View lyt_no_favorite;
    private CharSequence charSequence = null;
    private SharedPref sharedPref;

    public FragmentFavorite() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        root_view = inflater.inflate(R.layout.fragment_favorite, container, false);
        parent_view = getActivity().findViewById(R.id.lyt_content);

        sharedPref = new SharedPref(getActivity());

        lyt_no_favorite = root_view.findViewById(R.id.lyt_no_favorite);
        recyclerView = root_view.findViewById(R.id.recyclerView);

        ItemOffsetDecoration itemDecoration = new ItemOffsetDecoration(getActivity(), R.dimen.grid_space_channel);
        if (sharedPref.getChannelViewType() == CHANNEL_LIST_DEFAULT) {
            recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 1));
        } else if (sharedPref.getChannelViewType() == CHANNEL_GRID_2_COLUMN) {
            recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
            recyclerView.addItemDecoration(itemDecoration);
        } else if (sharedPref.getChannelViewType() == CHANNEL_GRID_3_COLUMN) {
            recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 3));
            recyclerView.addItemDecoration(itemDecoration);
        }

        databaseHandler = new DatabaseHandlerFavorite(getActivity());
        data = databaseHandler.getAllData();

        adapterPostList = new AdapterFavorite(getActivity(), recyclerView, data);
        recyclerView.setAdapter(adapterPostList);
        onChannelClickListener();
        addFavorite();

        if (data.size() == 0) {
            lyt_no_favorite.setVisibility(View.VISIBLE);
        } else {
            lyt_no_favorite.setVisibility(View.INVISIBLE);
        }

        return root_view;
    }

    @Override
    public void onResume() {

        super.onResume();

        data = databaseHandler.getAllData();
        adapterPostList = new AdapterFavorite(getActivity(), recyclerView, data);
        recyclerView.setAdapter(adapterPostList);
        onChannelClickListener();
        addFavorite();

        if (data.size() == 0) {
            lyt_no_favorite.setVisibility(View.VISIBLE);
        } else {
            lyt_no_favorite.setVisibility(View.INVISIBLE);
        }
    }

    public void onChannelClickListener() {
        adapterPostList.setOnItemClickListener((v, obj, position) -> {
            if (NetworkCheck.isConnect(getActivity())) {
                Intent intent = new Intent(getActivity(), ActivityChannelDetail.class);
                intent.putExtra(Constant.EXTRA_OBJC, obj);
                startActivity(intent);
            } else {
                Intent intent = new Intent(getActivity(), ActivityChannelDetailOffline.class);
                intent.putExtra(Constant.KEY_CHANNEL_CATEGORY, obj.category_name);
                intent.putExtra(Constant.KEY_CHANNEL_ID, obj.channel_id);
                intent.putExtra(Constant.KEY_CHANNEL_NAME, obj.channel_name);
                intent.putExtra(Constant.KEY_CHANNEL_IMAGE, obj.channel_image);
                intent.putExtra(Constant.KEY_CHANNEL_URL, obj.channel_url);
                intent.putExtra(Constant.KEY_CHANNEL_DESCRIPTION, obj.channel_description);
                intent.putExtra(Constant.KEY_CHANNEL_TYPE, obj.channel_type);
                intent.putExtra(Constant.KEY_VIDEO_ID, obj.video_id);
                startActivity(intent);
            }
        });
    }

    public void addFavorite() {
        adapterPostList.setOnItemOverflowClickListener((v, obj, position) -> {
            PopupMenu popup = new PopupMenu(getActivity(), v);
            MenuInflater inflater = popup.getMenuInflater();
            inflater.inflate(R.menu.menu_popup, popup.getMenu());
            popup.setOnMenuItemClickListener(item -> {
                switch (item.getItemId()) {
                    case R.id.menu_context_favorite:
                        if (charSequence.equals(getString(R.string.option_set_favorite))) {
                            databaseHandler.AddtoFavorite(new Channel(
                                    obj.category_name,
                                    obj.channel_id,
                                    obj.channel_name,
                                    obj.channel_image,
                                    obj.channel_url,
                                    obj.channel_description,
                                    obj.channel_type,
                                    obj.video_id
                            ));
                            Toast.makeText(getActivity(), getString(R.string.favorite_added), Toast.LENGTH_SHORT).show();

                        } else if (charSequence.equals(getString(R.string.option_unset_favorite))) {
                            databaseHandler.RemoveFav(new Channel(obj.channel_id));
                            Toast.makeText(getActivity(), getString(R.string.favorite_removed), Toast.LENGTH_SHORT).show();
                            refreshFragment();
                        }
                        return true;

                    case R.id.menu_context_quick_play:
                        if (obj.channel_type != null && obj.channel_type.equals("YOUTUBE")) {
                            Intent i = new Intent(getActivity(), ActivityYoutubePlayer.class);
                            i.putExtra("id", obj.video_id);
                            startActivity(i);
                        } else {
                            if (obj.channel_url != null && obj.channel_url.startsWith("rtmp://")) {
                                Intent intent = new Intent(getActivity(), ActivityRtmpPlayer.class);
                                intent.putExtra("url", obj.channel_url);
                                startActivity(intent);
                            } else {
                                Intent intent = new Intent(getActivity(), ActivityStreamPlayer.class);
                                intent.putExtra("url", obj.channel_url);
                                startActivity(intent);
                            }
                        }
                        return true;

                    default:
                }
                return false;
            });
            popup.show();

            databaseHandler = new DatabaseHandlerFavorite(getActivity());
            List<Channel> data = databaseHandler.getFavRow(obj.channel_id);
            if (data.size() == 0) {
                popup.getMenu().findItem(R.id.menu_context_favorite).setTitle(R.string.option_set_favorite);
                charSequence = popup.getMenu().findItem(R.id.menu_context_favorite).getTitle();
            } else {
                if (data.get(0).channel_id.equals(obj.channel_id)) {
                    popup.getMenu().findItem(R.id.menu_context_favorite).setTitle(R.string.option_unset_favorite);
                    charSequence = popup.getMenu().findItem(R.id.menu_context_favorite).getTitle();
                }
            }

        });
    }

    public void refreshFragment() {
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.detach(this).attach(this).commit();
    }


}
