-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 29, 2020 at 10:10 PM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `the_stream`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ads`
--

CREATE TABLE `tbl_ads` (
  `id` int(11) NOT NULL,
  `ad_status` varchar(5) NOT NULL DEFAULT 'on',
  `ad_type` varchar(45) NOT NULL DEFAULT 'admob',
  `admob_publisher_id` varchar(45) NOT NULL DEFAULT '0',
  `admob_app_id` varchar(255) NOT NULL DEFAULT '0',
  `admob_banner_unit_id` varchar(255) NOT NULL DEFAULT '0',
  `admob_interstitial_unit_id` varchar(255) NOT NULL DEFAULT '0',
  `admob_native_unit_id` varchar(255) NOT NULL DEFAULT '0',
  `fan_banner_unit_id` varchar(255) NOT NULL DEFAULT '0',
  `fan_interstitial_unit_id` varchar(255) NOT NULL DEFAULT '0',
  `fan_native_unit_id` varchar(255) NOT NULL DEFAULT '0',
  `startapp_app_id` varchar(255) NOT NULL DEFAULT '0',
  `interstitial_ad_interval` int(11) NOT NULL DEFAULT '3',
  `native_ad_interval` int(11) NOT NULL DEFAULT '20',
  `native_ad_index` int(11) NOT NULL DEFAULT '4',
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_ads`
--

INSERT INTO `tbl_ads` (`id`, `ad_status`, `ad_type`, `admob_publisher_id`, `admob_app_id`, `admob_banner_unit_id`, `admob_interstitial_unit_id`, `admob_native_unit_id`, `fan_banner_unit_id`, `fan_interstitial_unit_id`, `fan_native_unit_id`, `startapp_app_id`, `interstitial_ad_interval`, `native_ad_interval`, `native_ad_index`, `date_time`) VALUES
(1, 'on', 'fan', 'pub-3940256099942544', 'ca-app-pub-3940256099942544~3347511713', 'ca-app-pub-3940256099942544/6300978111', 'ca-app-pub-3940256099942544/1033173712', 'ca-app-pub-3940256099942544/2247696110', '243455220090448_245283556574281', '243455220090448_264906991278604', '243455220090448_264953971273906', '200857567', 3, 20, 5, '2020-07-26 14:37:53');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `cid` int(11) NOT NULL,
  `category_name` varchar(255) NOT NULL,
  `category_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`cid`, `category_name`, `category_image`) VALUES
(32, 'Entertainment', '3455-2017-04-13.png'),
(33, 'Sports', '2277-2017-04-13.png'),
(34, 'Education', '6094-2017-04-13.png'),
(35, 'Music', '7102-2017-04-13.png'),
(36, 'News', '2999-2017-04-20.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_channel`
--

CREATE TABLE `tbl_channel` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `channel_name` varchar(255) NOT NULL,
  `channel_image` varchar(255) NOT NULL,
  `channel_url` varchar(255) NOT NULL,
  `channel_description` text NOT NULL,
  `channel_type` varchar(45) NOT NULL DEFAULT 'URL',
  `video_id` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_channel`
--

INSERT INTO `tbl_channel` (`id`, `category_id`, `channel_name`, `channel_image`, `channel_url`, `channel_description`, `channel_type`, `video_id`) VALUES
(80, 36, 'CNN Indonesia', '1593011393_cnnindo.jpg', 'https://live.cnnindonesia.com/livecnn/smil:cnntv.smil/playlist.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(81, 32, 'Insan TV', '1593012434_insantv.jpg', 'http://wz.insantv.net/group/ngrp:insantv_mobile/playlist.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(82, 32, 'CBS News', '1593012316_cbsnews.png', 'https://dai.google.com/linear/hls/event/Sid4xiTQTkCT1SLu6rjUSQ/master.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(83, 32, 'Trans TV', '1593010147_logo-trans-tv.png', 'https://video.detik.com/transtv/smil:transtv.smil/playlist.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(84, 32, 'Ahsan TV', '1593011201_ahsantv.jpg', 'http://119.82.224.75:1935/live/ahsantv/playlist.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(85, 32, 'Metro TV', '1593010614_Metro TV.png', 'http://edge.metrotvnews.com:1935/live-edge/smil:metro.smil/playlist.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(86, 32, 'MNC Life', '1446-2017-04-20.jpg', 'https://edge.okezone.com/live/life.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(87, 33, 'Aljazeera', '1593010938_aljazeera.jpg', 'https://live-hls-web-aje.getaj.net/AJE/06.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(88, 36, 'TVRI', '1593009916_tvri.jpg', 'http://118.97.50.107/Content/HLS/Live/Channel(TVRINASIONAL)/Stream(04)/index.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(89, 34, 'Rodja TV', '1593009711_rodja.png', 'http://vids.rodja.tv:1935/live/rodja/chunklist_w1534883362.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(90, 36, 'Berita Satu', '1593009634_beritasatu.png', 'http://edge.linknetott.swiftserve.com/live/BsNew/amlst:beritasatunewsbs/playlist.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(91, 32, 'ADI TV', '1593009440_aditv.jpg', 'http://aditv.onlivestreaming.net/aditv/livestream/playlist.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(92, 32, 'Trans 7', '1593009303_gDlPjM8AetAJkcZLJ0Te.png', 'https://video.detik.com/trans7/smil:trans7.smil/playlist.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(93, 32, 'Disney Junior Asia', '1593011725_disneyjr.jpg', 'http://103.47.132.164/PLTV/88888888/224/3221226011/index.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(94, 32, 'HBO Asia', '1593013927_hbotv.jpg', 'http://220.158.149.14:9999/live/TV00000000000000000166@HHZT;LIVE', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', ''),
(95, 32, 'RCTI+', '1593014731_rcti+.jpg', 'https://cdn-livetv5.metube.id/hls/rcti_480/index.m3u8', '<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Dicet pro me ipsa virtus nec dubitabit isti vestro beato M. Effluit igitur voluptas corporis et prima quaeque avolat saepiusque relinquit causam paenitendi quam recordandi. Duo Reges: constructio interrete. Illis videtur, qui illud non dubitant bonum dicere -; Expectoque quid ad id, quod quaerebam, respondeas.</p>\r\n\r\n<p>Quem ad modum quis ambulet, sedeat, qui ductus oris, qui vultus in quoque sit? Iam id ipsum absurdum, maximum malum neglegi. Cur post Tarentum ad Archytam? Si quicquam extra virtutem habeatur in bonis. Quid enim possumus hoc agere divinius? Aliter homines, aliter philosophos loqui putas oportere? Tu vero, inquam, ducas licet, si sequetur; Videsne quam sit magna dissensio? Erit enim mecum, si tecum erit. Theophrasti igitur, inquit, tibi liber ille placet de beata vita? Quod idem cum vestri faciant, non satis magnam tribuunt inventoribus gratiam.</p>\r\n\r\n<p>Odium autem et invidiam facile vitabis. Bonum liberi: misera orbitas. Minime vero, inquit ille, consentit. Quae hic rei publicae vulnera inponebat, eadem ille sanabat.</p>\r\n\r\n<p>Ea possunt paria non esse. Quae hic rei publicae vulnera inponebat, eadem ille sanabat. Teneo, inquit, finem illi videri nihil dolere. Quid ergo attinet dicere: Nihil haberem, quod reprehenderem, si finitas cupiditates haberent? Inde igitur, inquit, ordiendum est.</p>\r\n', 'URL', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fcm_template`
--

CREATE TABLE `tbl_fcm_template` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL DEFAULT 'Notification',
  `message` text NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_fcm_template`
--

INSERT INTO `tbl_fcm_template` (`id`, `title`, `message`, `image`) VALUES
(22, 'The Stream', 'Hello World! this is The Stream App, you can purchase it on Codecanyon officially.', '7391-2017-04-23.png'),
(24, 'The Stream 3.0', 'New updated version is available now on Codecanyon!', '7351-2018-11-24.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fcm_token`
--

CREATE TABLE `tbl_fcm_token` (
  `id` int(11) NOT NULL,
  `user_android_token` varchar(500) NOT NULL,
  `user_unique_id` varchar(255) NOT NULL,
  `app_version` varchar(255) NOT NULL,
  `os_version` varchar(255) NOT NULL,
  `device_model` varchar(255) NOT NULL,
  `device_manufacturer` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_license`
--

CREATE TABLE `tbl_license` (
  `id` int(11) NOT NULL,
  `purchase_code` varchar(255) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `buyer` varchar(255) NOT NULL,
  `license_type` varchar(45) NOT NULL,
  `purchase_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_settings`
--

CREATE TABLE `tbl_settings` (
  `id` int(11) NOT NULL,
  `app_fcm_key` text NOT NULL,
  `api_key` varchar(255) NOT NULL,
  `package_name` varchar(255) NOT NULL DEFAULT 'com.app.thestream',
  `onesignal_app_id` varchar(500) NOT NULL DEFAULT '0',
  `onesignal_rest_api_key` varchar(500) NOT NULL DEFAULT '0',
  `privacy_policy` text NOT NULL,
  `providers` varchar(45) NOT NULL DEFAULT 'onesignal',
  `protocol_type` varchar(10) NOT NULL DEFAULT 'http://',
  `youtube_api_key` varchar(255) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_settings`
--

INSERT INTO `tbl_settings` (`id`, `app_fcm_key`, `api_key`, `package_name`, `onesignal_app_id`, `onesignal_rest_api_key`, `privacy_policy`, `providers`, `protocol_type`, `youtube_api_key`) VALUES
(1, '0', 'cda11bx8aITlKsXCpNB7yVLnOdEGqg342ZFrQzJRetkSoUMi9w', 'com.app.thestream', '0', '0', '<p>Solodroid built the The Stream App app as a Free app. This SERVICE is provided by Solodroid at no cost and is intended for use as is.</p>\r\n\r\n<p>This page is used to inform visitors regarding my policies with the collection, use, and disclosure of Personal Information if anyone decided to use my Service.</p>\r\n\r\n<p>If you choose to use my Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that I collect is used for providing and improving the Service. I will not use or share your information with anyone except as described in this Privacy Policy.</p>\r\n\r\n<p>The terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, which is accessible at The Stream App unless otherwise defined in this Privacy Policy.</p>\r\n\r\n<p><strong>Information Collection and Use</strong></p>\r\n\r\n<p>For a better experience, while using our Service, I may require you to provide us with certain personally identifiable information. The information that I request will be retained on your device and is not collected by me in any way.</p>\r\n\r\n<p>The app does use third party services that may collect information used to identify you.</p>\r\n\r\n<p>Link to privacy policy of third party service providers used by the app</p>\r\n\r\n<ul>\r\n	<li><a href=\"https://www.google.com/policies/privacy/\" target=\"_blank\">Google Play Services</a></li>\r\n	<li><a href=\"https://support.google.com/admob/answer/6128543?hl=en\" target=\"_blank\">AdMob</a></li>\r\n	<li><a href=\"https://onesignal.com/privacy_policy\" target=\"_blank\">One Signal</a></li>\r\n</ul>\r\n\r\n<p><strong>Log Data</strong></p>\r\n\r\n<p>I want to inform you that whenever you use my Service, in a case of an error in the app I collect data and information (through third party products) on your phone called Log Data. This Log Data may include information such as your device Internet Protocol (&ldquo;IP&rdquo;) address, device name, operating system version, the configuration of the app when utilizing my Service, the time and date of your use of the Service, and other statistics.</p>\r\n\r\n<p><strong>Cookies</strong></p>\r\n\r\n<p>Cookies are files with a small amount of data that are commonly used as anonymous unique identifiers. These are sent to your browser from the websites that you visit and are stored on your device&#39;s internal memory.</p>\r\n\r\n<p>This Service does not use these &ldquo;cookies&rdquo; explicitly. However, the app may use third party code and libraries that use &ldquo;cookies&rdquo; to collect information and improve their services. You have the option to either accept or refuse these cookies and know when a cookie is being sent to your device. If you choose to refuse our cookies, you may not be able to use some portions of this Service.</p>\r\n\r\n<p><strong>Service Providers</strong></p>\r\n\r\n<p>I may employ third-party companies and individuals due to the following reasons:</p>\r\n\r\n<ul>\r\n	<li>To facilitate our Service;</li>\r\n	<li>To provide the Service on our behalf;</li>\r\n	<li>To perform Service-related services; or</li>\r\n	<li>To assist us in analyzing how our Service is used.</li>\r\n</ul>\r\n\r\n<p>I want to inform users of this Service that these third parties have access to your Personal Information. The reason is to perform the tasks assigned to them on our behalf. However, they are obligated not to disclose or use the information for any other purpose.</p>\r\n\r\n<p><strong>Security</strong></p>\r\n\r\n<p>I value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and I cannot guarantee its absolute security.</p>\r\n\r\n<p><strong>Links to Other Sites</strong></p>\r\n\r\n<p>This Service may contain links to other sites. If you click on a third-party link, you will be directed to that site. Note that these external sites are not operated by me. Therefore, I strongly advise you to review the Privacy Policy of these websites. I have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services.</p>\r\n\r\n<p><strong>Children&rsquo;s Privacy</strong></p>\r\n\r\n<p>These Services do not address anyone under the age of 13. I do not knowingly collect personally identifiable information from children under 13. In the case I discover that a child under 13 has provided me with personal information, I immediately delete this from our servers. If you are a parent or guardian and you are aware that your child has provided us with personal information, please contact me so that I will be able to do necessary actions.</p>\r\n\r\n<p><strong>Changes to This Privacy Policy</strong></p>\r\n\r\n<p>I may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. I will notify you of any changes by posting the new Privacy Policy on this page.</p>\r\n\r\n<p>This policy is effective as of 2020-06-08</p>\r\n\r\n<p><strong>Contact Us</strong></p>\r\n\r\n<p>If you have any questions or suggestions about my Privacy Policy, do not hesitate to contact me at help.solodroid@gmail.com.</p>\r\n', 'onesignal', 'http', '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_role` enum('100','101','102') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `email`, `user_role`) VALUES
(1, 'admin', 'd82494f05d6917ba02f7aaa29689ccb444bb73f20380876cb05d1f37537b7892', 'help.solodroid@gmail.com', '100');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_ads`
--
ALTER TABLE `tbl_ads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_channel`
--
ALTER TABLE `tbl_channel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fcm_template`
--
ALTER TABLE `tbl_fcm_template`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fcm_token`
--
ALTER TABLE `tbl_fcm_token`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_license`
--
ALTER TABLE `tbl_license`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_ads`
--
ALTER TABLE `tbl_ads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `tbl_channel`
--
ALTER TABLE `tbl_channel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=96;

--
-- AUTO_INCREMENT for table `tbl_fcm_template`
--
ALTER TABLE `tbl_fcm_template`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_fcm_token`
--
ALTER TABLE `tbl_fcm_token`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_license`
--
ALTER TABLE `tbl_license`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_settings`
--
ALTER TABLE `tbl_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
