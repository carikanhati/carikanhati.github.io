package com.app.thestream.activities;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.app.thestream.BuildConfig;
import com.app.thestream.Config;
import com.app.thestream.R;
import com.app.thestream.adapters.AdapterSuggested;
import com.app.thestream.callbacks.CallbackChannelDetail;
import com.app.thestream.databases.DatabaseHandlerFavorite;
import com.app.thestream.models.Channel;
import com.app.thestream.notification.NotificationUtils;
import com.app.thestream.rests.ApiInterface;
import com.app.thestream.rests.RestAdapter;
import com.app.thestream.utils.AdsPref;
import com.app.thestream.utils.AppBarLayoutBehavior;
import com.app.thestream.utils.Constant;
import com.app.thestream.utils.NativeTemplateStyle;
import com.app.thestream.utils.NetworkCheck;
import com.app.thestream.utils.SharedPref;
import com.app.thestream.utils.TemplateView;
import com.app.thestream.utils.Tools;
import com.facebook.ads.AdError;
import com.facebook.ads.AdOptionsView;
import com.facebook.ads.AdSize;
import com.facebook.ads.NativeAd;
import com.facebook.ads.NativeAdLayout;
import com.facebook.ads.NativeAdListener;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.snackbar.Snackbar;
import com.squareup.picasso.Picasso;
import com.startapp.sdk.ads.banner.Banner;
import com.startapp.sdk.ads.banner.BannerListener;
import com.startapp.sdk.ads.nativead.NativeAdDetails;
import com.startapp.sdk.ads.nativead.NativeAdPreferences;
import com.startapp.sdk.ads.nativead.StartAppNativeAd;
import com.startapp.sdk.adsbase.Ad;
import com.startapp.sdk.adsbase.adlisteners.AdEventListener;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.schedulers.Schedulers;

import static com.app.thestream.utils.Constant.ADMOB;
import static com.app.thestream.utils.Constant.AD_STATUS_ON;
import static com.app.thestream.utils.Constant.FAN;
import static com.app.thestream.utils.Constant.STARTAPP;
import static com.app.thestream.utils.Constant.STARTAPP_IMAGE_LARGE;
import static com.app.thestream.utils.Constant.STARTAPP_IMAGE_XSMALL;

public class ActivityChannelDetail extends AppCompatActivity {

    private LinearLayout lyt_main_content;
    private Channel post;
    ImageView channel_image;
    private CompositeDisposable mCompositeDisposable = new CompositeDisposable();
    TextView channel_name, channel_category, title_toolbar;
    WebView channel_description;
    DatabaseHandlerFavorite databaseHandler;
    CoordinatorLayout parent_view;
    BroadcastReceiver broadcastReceiver;
    private ShimmerFrameLayout lyt_shimmer;
    RelativeLayout lyt_suggested;
    private SwipeRefreshLayout swipe_refresh;
    private FrameLayout adContainerView;
    private TemplateView native_template;
    private MediaView mediaView;
    private AdView adView;
    com.facebook.ads.AdView fanAdView;
    private StartAppNativeAd startAppNativeAd;
    private NativeAdDetails nativeAd = null;
    SharedPref sharedPref;
    AdsPref adsPref;
    ImageButton btn_favorite, btn_share;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Tools.getTheme(this);
        setContentView(R.layout.activity_detail);

        sharedPref = new SharedPref(this);
        adsPref = new AdsPref(this);

        if (Config.ENABLE_RTL_MODE) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            }
        }

        databaseHandler = new DatabaseHandlerFavorite(getApplicationContext());

        AppBarLayout appBarLayout = findViewById(R.id.appbar);
        ((CoordinatorLayout.LayoutParams) appBarLayout.getLayoutParams()).setBehavior(new AppBarLayoutBehavior());

        swipe_refresh = findViewById(R.id.swipe_refresh_layout);
        swipe_refresh.setColorSchemeResources(R.color.colorPrimary);
        swipe_refresh.setRefreshing(false);

        lyt_main_content = findViewById(R.id.lyt_main_content);
        lyt_shimmer = findViewById(R.id.shimmer_view_container);
        parent_view = findViewById(R.id.lyt_content);

        title_toolbar = findViewById(R.id.title_toolbar);
        btn_favorite = findViewById(R.id.btn_favorite);
        btn_share = findViewById(R.id.btn_share);
        channel_image = findViewById(R.id.channel_image);
        channel_name = findViewById(R.id.channel_name);
        channel_category = findViewById(R.id.channel_category);
        channel_description = findViewById(R.id.channel_description);

        native_template = findViewById(R.id.admob_native_template);
        mediaView = findViewById(R.id.media_view);

        lyt_suggested = findViewById(R.id.lyt_suggested);

        post = (Channel) getIntent().getSerializableExtra(Constant.EXTRA_OBJC);

        requestAction();

        swipe_refresh.setOnRefreshListener(() -> {
            if (mCompositeDisposable != null && !mCompositeDisposable.isDisposed()) {
                mCompositeDisposable.dispose();
                mCompositeDisposable = new CompositeDisposable();
            }
            lyt_shimmer.setVisibility(View.VISIBLE);
            lyt_shimmer.startShimmer();
            lyt_main_content.setVisibility(View.GONE);
            requestAction();
        });

        initToolbar();
        initAdNetwork();
        onReceiveNotification();

    }

    private void requestAction() {
        showFailedView(false, "");
        swipeProgress(true);
        new Handler().postDelayed(this::requestPostData, 200);
    }

    private void requestPostData() {
        ApiInterface apiInterface = RestAdapter.createAPI();
        mCompositeDisposable.add(apiInterface.getChannelDetail(post.channel_id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe((resp, throwable) -> {
                    if (resp != null && resp.status.equals("ok")) {
                        displayAllData(resp);
                        swipeProgress(false);
                        lyt_main_content.setVisibility(View.VISIBLE);
                    } else {
                        onFailRequest();
                    }
                }));
    }

    private void onFailRequest() {
        swipeProgress(false);
        lyt_main_content.setVisibility(View.GONE);
        if (NetworkCheck.isConnect(ActivityChannelDetail.this)) {
            showFailedView(true, getString(R.string.failed_text));
        } else {
            showFailedView(true, getString(R.string.failed_text));
        }
    }

    private void showFailedView(boolean show, String message) {
        View lyt_failed = findViewById(R.id.lyt_failed_home);
        ((TextView) findViewById(R.id.failed_message)).setText(message);
        if (show) {
            lyt_failed.setVisibility(View.VISIBLE);
        } else {
            lyt_failed.setVisibility(View.GONE);
        }
        findViewById(R.id.failed_retry).setOnClickListener(view -> requestAction());
    }

    private void swipeProgress(final boolean show) {
        if (!show) {
            swipe_refresh.setRefreshing(show);
            lyt_shimmer.setVisibility(View.GONE);
            lyt_shimmer.stopShimmer();
            lyt_main_content.setVisibility(View.VISIBLE);
            return;
        }
        lyt_main_content.setVisibility(View.GONE);
    }

    private void displayAllData(CallbackChannelDetail resp) {
        displayData(resp.post);
        displaySuggested(resp.suggested);
    }

    public void displayData(final Channel post) {

        channel_name.setText(post.channel_name);

        channel_category.setText(post.category_name);
        if (Config.ENABLE_CHANNEL_LIST_CATEGORY_NAME) {
            channel_category.setVisibility(View.VISIBLE);
        } else {
            channel_category.setVisibility(View.GONE);
        }

        if (post.channel_type != null && post.channel_type.equals("YOUTUBE")) {
            Picasso.get()
                    .load(Constant.YOUTUBE_IMG_FRONT + post.video_id + Constant.YOUTUBE_IMG_BACK)
                    .placeholder(R.drawable.ic_thumbnail)
                    .into(channel_image);
        } else {
            Picasso.get()
                    .load(Config.ADMIN_PANEL_URL + "/upload/" + post.channel_image)
                    .placeholder(R.drawable.ic_thumbnail)
                    .into(channel_image);
        }

        channel_image.setOnClickListener(view -> {

            if (NetworkCheck.isNetworkAvailable(ActivityChannelDetail.this)) {

                if (post.channel_type != null && post.channel_type.equals("YOUTUBE")) {
                    Intent i = new Intent(ActivityChannelDetail.this, ActivityYoutubePlayer.class);
                    i.putExtra("id", post.video_id);
                    startActivity(i);
                } else {
                    if (post.channel_url != null && post.channel_url.startsWith("rtmp://")) {
                        Intent intent = new Intent(ActivityChannelDetail.this, ActivityRtmpPlayer.class);
                        intent.putExtra("url", post.channel_url);
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(ActivityChannelDetail.this, ActivityStreamPlayer.class);
                        intent.putExtra("url", post.channel_url);
                        startActivity(intent);
                    }
                }

                //showInterstitialAd();

            } else {
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.network_required), Toast.LENGTH_SHORT).show();
            }

        });

        channel_description.setBackgroundColor(Color.TRANSPARENT);
        channel_description.setFocusableInTouchMode(false);
        channel_description.setFocusable(false);
        channel_description.getSettings().setDefaultTextEncodingName("UTF-8");

        WebSettings webSettings = channel_description.getSettings();
        Resources res = getResources();
        int fontSize = res.getInteger(R.integer.font_size);
        webSettings.setDefaultFontSize(fontSize);

        String mimeType = "text/html; charset=UTF-8";
        String encoding = "utf-8";
        String htmlText = post.channel_description;

        String bg_paragraph;
        if (sharedPref.getIsDarkTheme()) {
            bg_paragraph = "<style type=\"text/css\">body{color: #eeeeee;}";
        } else {
            bg_paragraph = "<style type=\"text/css\">body{color: #000000;}";
        }

        String text = "<html><head>"
                + "<style>img{max-width:100%;height:auto;} figure{max-width:100%;height:auto;} iframe{width:100%;}</style> "
                + bg_paragraph
                + "</style></head>"
                + "<body>"
                + htmlText
                + "</body></html>";

        String text_rtl = "<html dir='rtl'><head>"
                + "<style>img{max-width:100%;height:auto;} figure{max-width:100%;height:auto;} iframe{width:100%;}</style> "
                + bg_paragraph
                + "</style></head>"
                + "<body>"
                + htmlText
                + "</body></html>";

        if (Config.ENABLE_RTL_MODE) {
            channel_description.loadDataWithBaseURL(null, text_rtl, mimeType, encoding, null);
        } else {
            channel_description.loadDataWithBaseURL(null, text, mimeType, encoding, null);
        }

        btn_share.setOnClickListener(view -> {
            String share_title = android.text.Html.fromHtml(post.channel_name).toString();
            String share_content = android.text.Html.fromHtml(getResources().getString(R.string.share_content)).toString();
            Intent sendIntent = new Intent();
            sendIntent.setAction(Intent.ACTION_SEND);
            sendIntent.putExtra(Intent.EXTRA_TEXT, share_title + "\n\n" + share_content + "\n\n" + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID);
            sendIntent.setType("text/plain");
            startActivity(sendIntent);
        });

        addToFavorite();

        new Handler().postDelayed(() -> lyt_suggested.setVisibility(View.VISIBLE), 1000);

    }

    private void displaySuggested(List<Channel> list) {

        RecyclerView recyclerView = findViewById(R.id.recycler_view_suggested);
        recyclerView.setLayoutManager(new LinearLayoutManager(ActivityChannelDetail.this));
        AdapterSuggested adapterSuggested = new AdapterSuggested(ActivityChannelDetail.this, recyclerView, list);
        recyclerView.setAdapter(adapterSuggested);
        recyclerView.setNestedScrollingEnabled(false);
        adapterSuggested.setOnItemClickListener((view, obj, position) -> {
            Intent intent = new Intent(getApplicationContext(), ActivityChannelDetail.class);
            intent.putExtra(Constant.EXTRA_OBJC, obj);
            startActivity(intent);
        });

        TextView txt_suggested = findViewById(R.id.txt_suggested);
        if (list.size() > 0) {
            txt_suggested.setText(getResources().getString(R.string.txt_suggested));
        } else {
            txt_suggested.setText("");
        }

    }

    private void initToolbar() {
        final Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (sharedPref.getIsDarkTheme()) {
            toolbar.setBackgroundColor(getResources().getColor(R.color.colorToolbarDark));
        } else {
            toolbar.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
        }

        final ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
            getSupportActionBar().setTitle("");
        }

        title_toolbar.setText(post.category_name);

    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public void addToFavorite() {

        List<Channel> data = databaseHandler.getFavRow(post.channel_id);
        if (data.size() == 0) {
            btn_favorite.setImageResource(R.drawable.ic_favorite_outline_white);
        } else {
            if (data.get(0).getChannel_id().equals(post.channel_id)) {
                btn_favorite.setImageResource(R.drawable.ic_favorite_white);
            }
        }

        btn_favorite.setOnClickListener(view -> {
            List<Channel> data1 = databaseHandler.getFavRow(post.channel_id);
            if (data1.size() == 0) {
                databaseHandler.AddtoFavorite(new Channel(
                        post.category_name,
                        post.channel_id,
                        post.channel_name,
                        post.channel_image,
                        post.channel_url,
                        post.channel_description,
                        post.channel_type,
                        post.video_id
                ));
                Snackbar.make(parent_view, R.string.favorite_added, Snackbar.LENGTH_SHORT).show();
                btn_favorite.setImageResource(R.drawable.ic_favorite_white);

            } else {
                if (data1.get(0).getChannel_id().equals(post.channel_id)) {
                    databaseHandler.RemoveFav(new Channel(post.channel_id));
                    Snackbar.make(parent_view, R.string.favorite_removed, Snackbar.LENGTH_SHORT).show();
                    btn_favorite.setImageResource(R.drawable.ic_favorite_outline_white);
                }
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == android.R.id.home) {
            onBackPressed();
        } else {
            return super.onOptionsItemSelected(menuItem);
        }
        return true;
    }

    public void initAdNetwork() {
        if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(ADMOB)) {
            MobileAds.initialize(ActivityChannelDetail.this, adsPref.getAdMobAppId());
            loadAdMobBannerAd();
            loadAdMobNativeAd();
        } else if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(FAN)) {
            loadFanBannerAd();
            loadFanNativeAd();
        } else if (adsPref.getAdStatus().equals(AD_STATUS_ON) && adsPref.getAdType().equals(STARTAPP)) {
            loadStartAppBannerAd();
            loadStartAppNativeAd();
        }
    }

    public void loadAdMobBannerAd() {
        if (!adsPref.getAdMobBannerId().equals("0")) {
            adContainerView = findViewById(R.id.admob_banner_view_container);
            adContainerView.post(() -> {
                adView = new AdView(this);
                adView.setAdUnitId(adsPref.getAdMobBannerId());
                adContainerView.removeAllViews();
                adContainerView.addView(adView);
                adView.setAdSize(Tools.getAdSize(this));
                adView.loadAd(Tools.getAdRequest(this));
                adView.setAdListener(new AdListener() {
                    @Override
                    public void onAdClosed() {
                    }

                    @Override
                    public void onAdFailedToLoad(int error) {
                        adContainerView.setVisibility(View.GONE);
                    }

                    @Override
                    public void onAdLeftApplication() {
                    }

                    @Override
                    public void onAdOpened() {
                    }

                    @Override
                    public void onAdLoaded() {
                        adContainerView.setVisibility(View.VISIBLE);
                    }
                });
            });
        }
    }

    private void loadAdMobNativeAd() {
        if (!adsPref.getAdMobNativeId().equals("0")) {
            AdLoader adLoader = new AdLoader.Builder(this, adsPref.getAdMobNativeId())
                    .forUnifiedNativeAd(unifiedNativeAd -> {
                        if (sharedPref.getIsDarkTheme()) {
                            ColorDrawable colorDrawable = new ColorDrawable(ContextCompat.getColor(this, R.color.colorBackgroundDark));
                            NativeTemplateStyle styles = new NativeTemplateStyle.Builder().withMainBackgroundColor(colorDrawable).build();
                            native_template.setStyles(styles);
                        } else {
                            ColorDrawable colorDrawable = new ColorDrawable(ContextCompat.getColor(this, R.color.colorBackgroundLight));
                            NativeTemplateStyle styles = new NativeTemplateStyle.Builder().withMainBackgroundColor(colorDrawable).build();
                            native_template.setStyles(styles);
                        }
                        mediaView.setImageScaleType(ImageView.ScaleType.CENTER_CROP);
                        native_template.setNativeAd(unifiedNativeAd);
                        native_template.setVisibility(View.VISIBLE);
                    })
                    .withAdListener(new AdListener() {
                        @Override
                        public void onAdFailedToLoad(int errorCode) {
                            native_template.setVisibility(View.GONE);
                        }
                    })
                    .build();
            adLoader.loadAd(Tools.getAdRequest(this));
        }
    }

    private void loadFanBannerAd() {
        if (!adsPref.getFanBannerUnitId().equals("0")) {
            if (BuildConfig.DEBUG) {
                fanAdView = new com.facebook.ads.AdView(this, "IMG_16_9_APP_INSTALL#" + adsPref.getFanBannerUnitId(), AdSize.BANNER_HEIGHT_50);
            } else {
                fanAdView = new com.facebook.ads.AdView(this, adsPref.getFanBannerUnitId(), AdSize.BANNER_HEIGHT_50);
            }
            LinearLayout adContainer = findViewById(R.id.fan_banner_view_container);
            // Add the ad view to your activity layout
            adContainer.addView(fanAdView);
            com.facebook.ads.AdListener adListener = new com.facebook.ads.AdListener() {
                @Override
                public void onError(com.facebook.ads.Ad ad, AdError adError) {
                    adContainer.setVisibility(View.GONE);
                }

                @Override
                public void onAdLoaded(com.facebook.ads.Ad ad) {
                    adContainer.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAdClicked(com.facebook.ads.Ad ad) {

                }

                @Override
                public void onLoggingImpression(com.facebook.ads.Ad ad) {

                }
            };
            com.facebook.ads.AdView.AdViewLoadConfig loadAdConfig = fanAdView.buildLoadAdConfig().withAdListener(adListener).build();
            fanAdView.loadAd(loadAdConfig);
        }
    }

    private void loadFanNativeAd() {
        if (!adsPref.getFanNativeUnitId().equals("0")) {
            final NativeAd nativeAd;
            final RelativeLayout lyt_fan_native = findViewById(R.id.lyt_fan_native);
            final NativeAdLayout nativeAdLayout = findViewById(R.id.native_ad_container);
            if (BuildConfig.DEBUG) {
                nativeAd = new NativeAd(this, "IMG_16_9_APP_INSTALL#" + adsPref.getFanNativeUnitId());
            } else {
                nativeAd = new NativeAd(this, adsPref.getFanNativeUnitId());
            }
            NativeAdListener nativeAdListener = new NativeAdListener() {
                @Override
                public void onMediaDownloaded(com.facebook.ads.Ad ad) {

                }

                @Override
                public void onError(com.facebook.ads.Ad ad, AdError adError) {

                }

                @Override
                public void onAdLoaded(com.facebook.ads.Ad ad) {
                    // Race condition, load() called again before last ad was displayed
                        lyt_fan_native.setVisibility(View.VISIBLE);
                        if (nativeAd != ad) {
                            return;
                        }
                        // Inflate Native Ad into Container
                        //inflateAd(nativeAd);
                        nativeAd.unregisterView();
                        // Add the Ad view into the ad container.
                        LayoutInflater inflater = LayoutInflater.from(getApplicationContext());
                        // Inflate the Ad view.  The layout referenced should be the one you created in the last step.
                        LinearLayout nativeAdView = (LinearLayout) inflater.inflate(R.layout.gnt_fan_medium_template, nativeAdLayout, false);
                        nativeAdLayout.addView(nativeAdView);

                        // Add the AdOptionsView
                        LinearLayout adChoicesContainer = nativeAdView.findViewById(R.id.ad_choices_container);
                        AdOptionsView adOptionsView = new AdOptionsView(getApplicationContext(), nativeAd, nativeAdLayout);
                        adChoicesContainer.removeAllViews();
                        adChoicesContainer.addView(adOptionsView, 0);

                        // Create native UI using the ad metadata.
                        TextView nativeAdTitle = nativeAdView.findViewById(R.id.native_ad_title);
                        com.facebook.ads.MediaView nativeAdMedia = nativeAdView.findViewById(R.id.native_ad_media);
                        TextView nativeAdSocialContext = nativeAdView.findViewById(R.id.native_ad_social_context);
                        TextView nativeAdBody = nativeAdView.findViewById(R.id.native_ad_body);
                        TextView sponsoredLabel = nativeAdView.findViewById(R.id.native_ad_sponsored_label);
                        Button nativeAdCallToAction = nativeAdView.findViewById(R.id.native_ad_call_to_action);
                        LinearLayout ad_unit = nativeAdView.findViewById(R.id.ad_unit);

                        if (sharedPref.getIsDarkTheme()) {
                            nativeAdTitle.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorWhite));
                            nativeAdSocialContext.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.colorWhite));
                            sponsoredLabel.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.sub_text_color));
                            nativeAdBody.setTextColor(ContextCompat.getColor(getApplicationContext(), R.color.sub_text_color));
                        }

                        // Set the Text.
                        nativeAdTitle.setText(nativeAd.getAdvertiserName());
                        nativeAdBody.setText(nativeAd.getAdBodyText());
                        nativeAdSocialContext.setText(nativeAd.getAdSocialContext());
                        nativeAdCallToAction.setVisibility(nativeAd.hasCallToAction() ? View.VISIBLE : View.INVISIBLE);
                        nativeAdCallToAction.setText(nativeAd.getAdCallToAction());
                        sponsoredLabel.setText(nativeAd.getSponsoredTranslation());

                        // Create a list of clickable views
                        List<View> clickableViews = new ArrayList<>();
                        clickableViews.add(nativeAdTitle);
                        clickableViews.add(ad_unit);
                        clickableViews.add(nativeAdCallToAction);

                        // Register the Title and CTA button to listen for clicks.
                        nativeAd.registerViewForInteraction(nativeAdView, nativeAdMedia, clickableViews);

                }

                @Override
                public void onAdClicked(com.facebook.ads.Ad ad) {

                }

                @Override
                public void onLoggingImpression(com.facebook.ads.Ad ad) {

                }
            };

            NativeAd.NativeLoadAdConfig loadAdConfig = nativeAd.buildLoadAdConfig().withAdListener(nativeAdListener).build();
            nativeAd.loadAd(loadAdConfig);
        }
    }

    private void loadStartAppBannerAd() {
        if (!adsPref.getStartappAppID().equals("0")) {
            RelativeLayout bannerLayout = findViewById(R.id.startapp_banner_view_container);
            Banner banner = new Banner(this, new BannerListener() {
                @Override
                public void onReceiveAd(View banner) {
                    bannerLayout.setVisibility(View.VISIBLE);
                }

                @Override
                public void onFailedToReceiveAd(View banner) {
                    bannerLayout.setVisibility(View.GONE);
                }

                @Override
                public void onImpression(View view) {

                }

                @Override
                public void onClick(View banner) {
                }
            });
            bannerLayout.addView(banner);
        }
    }

    private void loadStartAppNativeAd() {
        if (!adsPref.getStartappAppID().equals("0")) {
            View lyt_startapp_native = findViewById(R.id.startapp_native_template);
            ImageView startapp_native_image = findViewById(R.id.startapp_native_image);
            ImageView startapp_native_secondary_image = findViewById(R.id.startapp_native_secondary_image);
            TextView startapp_native_title = findViewById(R.id.startapp_native_title);
            TextView startapp_native_description = findViewById(R.id.startapp_native_description);
            Button startapp_native_button = findViewById(R.id.startapp_native_button);
            startapp_native_button.setOnClickListener(v1 -> lyt_startapp_native.performClick());

            startAppNativeAd = new StartAppNativeAd(this);
            NativeAdPreferences nativePrefs = new NativeAdPreferences()
                    .setAdsNumber(1)
                    .setAutoBitmapDownload(true)
                    .setPrimaryImageSize(STARTAPP_IMAGE_LARGE)
                    .setSecondaryImageSize(STARTAPP_IMAGE_XSMALL);
            AdEventListener adListener = new AdEventListener() {
                @Override
                public void onReceiveAd(Ad arg0) {
                    ArrayList<NativeAdDetails> nativeAdsList = startAppNativeAd.getNativeAds();
                    if (nativeAdsList.size() > 0) {
                        nativeAd = nativeAdsList.get(0);
                    }
                    if (nativeAd != null) {;
                        startapp_native_image.setImageBitmap(nativeAd.getImageBitmap());
                        startapp_native_secondary_image.setImageBitmap(nativeAd.getSecondaryImageBitmap());
                        startapp_native_title.setText(nativeAd.getTitle());
                        startapp_native_description.setText(nativeAd.getDescription());
                        startapp_native_button.setText(nativeAd.isApp() ? "Install" : "Open");
                        nativeAd.registerViewForInteraction(lyt_startapp_native);
                    }
                    lyt_startapp_native.setVisibility(View.VISIBLE);
                }

                @Override
                public void onFailedToReceiveAd(Ad arg0) {
                    lyt_startapp_native.setVisibility(View.GONE);
                }
            };
            startAppNativeAd.loadAd(nativePrefs, adListener);
        }
    }

    public void onDestroy() {
        super.onDestroy();
        lyt_shimmer.stopShimmer();
        if (mCompositeDisposable != null && !mCompositeDisposable.isDisposed()) {
            mCompositeDisposable.clear();
        }
    }

    public void onReceiveNotification() {
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(Constant.PUSH_NOTIFICATION)) {
                    NotificationUtils.showDialogNotification(ActivityChannelDetail.this, intent);
                }
            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, new IntentFilter(Constant.REGISTRATION_COMPLETE));
        LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, new IntentFilter(Constant.PUSH_NOTIFICATION));
    }

    @Override
    protected void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(broadcastReceiver);
        super.onPause();
    }

}
