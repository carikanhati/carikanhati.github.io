package com.app.thestream.utils;

public class Constant {

    public static final String EXTRA_OBJC = "key.EXTRA_OBJC";
    public static final String KEY_CHANNEL_CATEGORY = "key.CHANNEL_CATEGORY";
    public static final String KEY_CHANNEL_ID = "key.CHANNEL_ID";
    public static final String KEY_CHANNEL_NAME = "key.CHANNEL_NAME";
    public static final String KEY_CHANNEL_IMAGE = "key.CHANNEL_IMAGE";
    public static final String KEY_CHANNEL_URL = "key.CHANNEL_URL";
    public static final String KEY_CHANNEL_DESCRIPTION = "key.CHANNEL_DESCRIPTION";
    public static final String KEY_CHANNEL_TYPE = "key.CHANNEL_TYPE";
    public static final String KEY_VIDEO_ID = "key.VIDEO_ID";
    public static final String YOUTUBE_IMG_FRONT = "https://img.youtube.com/vi/";
    public static final String YOUTUBE_IMG_BACK = "/mqdefault.jpg";
    public static final String AD_STATUS_ON = "on";
    public static final String ADMOB = "admob";
    public static final String FAN = "fan";
    public static final String STARTAPP = "startapp";

    //startapp native ad image parameters
    public static final int STARTAPP_IMAGE_XSMALL = 1; //for image size 100px X 100px
    public static final int STARTAPP_IMAGE_SMALL = 2; //for image size 150px X 150px
    public static final int STARTAPP_IMAGE_MEDIUM = 3; //for image size 340px X 340px
    public static final int STARTAPP_IMAGE_LARGE = 4; //for image size 1200px X 628px

    //push notification
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String PUSH_NOTIFICATION = "pushNotification";
    public static final String NOTIFICATION_CHANNEL_NAME = "the_stream_channel_01";


    //other
    public static final long DELAY_TIME = 1000;
    public static final int MAX_SEARCH_RESULT = 100;
    public static final int SPACE_ITEM_DECORATION = 6;

    public static final int CHANNEL_LIST_DEFAULT = 0;
    public static final int CHANNEL_GRID_2_COLUMN = 1;
    public static final int CHANNEL_GRID_3_COLUMN = 2;

    public static final int CATEGORY_LIST_DEFAULT = 0;
    public static final int CATEGORY_GRID_2_COLUMN = 1;
    public static final int CATEGORY_GRID_3_COLUMN = 2;

    public static final int PLAYER_MODE_PORTRAIT = 0;
    public static final int PLAYER_MODE_LANDSCAPE = 1;

}