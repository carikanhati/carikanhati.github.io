package com.app.thestream.callbacks;

import com.app.thestream.models.Ads;

public class CallbackAds {

    public String status;
    public Ads ads = null;

}
