package com.app.thestream.fragments;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.app.thestream.BuildConfig;
import com.app.thestream.R;
import com.app.thestream.activities.ActivityPrivacyPolicy;
import com.app.thestream.activities.MainActivity;
import com.app.thestream.utils.SharedPref;

import static com.app.thestream.utils.Constant.CATEGORY_GRID_2_COLUMN;
import static com.app.thestream.utils.Constant.CATEGORY_GRID_3_COLUMN;
import static com.app.thestream.utils.Constant.CATEGORY_LIST_DEFAULT;
import static com.app.thestream.utils.Constant.CHANNEL_GRID_2_COLUMN;
import static com.app.thestream.utils.Constant.CHANNEL_GRID_3_COLUMN;
import static com.app.thestream.utils.Constant.CHANNEL_LIST_DEFAULT;
import static com.app.thestream.utils.Constant.PLAYER_MODE_LANDSCAPE;
import static com.app.thestream.utils.Constant.PLAYER_MODE_PORTRAIT;


public class FragmentSettings extends Fragment {

    View root_view, parent_view;
    SharedPref sharedPref;
    Switch switch_theme;
    Switch switch_list;
    TextView txt_current_video_list;
    TextView txt_current_category_list;
    TextView txt_current_player_mode;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        root_view = inflater.inflate(R.layout.fragment_settings, container, false);
        parent_view = getActivity().findViewById(R.id.lyt_content);

        sharedPref = new SharedPref(getActivity());

        initComponent();

        return root_view;
    }

    private void initComponent() {

        txt_current_video_list = root_view.findViewById(R.id.txt_current_video_list);
        if (sharedPref.getChannelViewType() == CHANNEL_LIST_DEFAULT) {
            txt_current_video_list.setText(getResources().getString(R.string.single_choice_default));
        } else if (sharedPref.getChannelViewType() == CHANNEL_GRID_2_COLUMN) {
            txt_current_video_list.setText(getResources().getString(R.string.single_choice_grid2));
        } else if (sharedPref.getChannelViewType() == CHANNEL_GRID_3_COLUMN) {
            txt_current_video_list.setText(getResources().getString(R.string.single_choice_grid3));
        }

        txt_current_category_list = root_view.findViewById(R.id.txt_current_category_list);
        if (sharedPref.getCategoryViewType() == CATEGORY_LIST_DEFAULT) {
            txt_current_category_list.setText(getResources().getString(R.string.single_choice_list));
        } else if (sharedPref.getCategoryViewType() == CATEGORY_GRID_2_COLUMN) {
            txt_current_category_list.setText(getResources().getString(R.string.single_choice_grid_2));
        } else if (sharedPref.getCategoryViewType() == CATEGORY_GRID_3_COLUMN) {
            txt_current_category_list.setText(getResources().getString(R.string.single_choice_grid_3));
        }

        txt_current_player_mode = root_view.findViewById(R.id.txt_current_player_mode);
        if (sharedPref.getPlayerMode() == PLAYER_MODE_PORTRAIT) {
            txt_current_player_mode.setText(getResources().getString(R.string.player_portrait));
        } else if (sharedPref.getCategoryViewType() == PLAYER_MODE_LANDSCAPE) {
            txt_current_player_mode.setText(getResources().getString(R.string.player_landscape));
        }

        onThemeChanged();
        changeVideoListViewType();
        changeCategoryListViewType();
        changePlayerMode();

        root_view.findViewById(R.id.btn_privacy_policy).setOnClickListener(view -> startActivity(new Intent(getActivity(), ActivityPrivacyPolicy.class)));
        root_view.findViewById(R.id.btn_rate).setOnClickListener(view -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID))));
        root_view.findViewById(R.id.btn_more).setOnClickListener(view -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.play_more_apps)))));
        root_view.findViewById(R.id.btn_about).setOnClickListener(view -> aboutDialog());
    }

    private void onThemeChanged() {
        switch_theme = root_view.findViewById(R.id.switch_theme);
        if (sharedPref.getIsDarkTheme()) {
            switch_theme.setChecked(true);
        } else {
            switch_theme.setChecked(false);
        }
        switch_theme.setOnCheckedChangeListener((buttonView, isChecked) -> {
            sharedPref.setIsDarkTheme(isChecked);
            Intent intent = new Intent(getActivity(), MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }

    private void changeVideoListViewType() {

        root_view.findViewById(R.id.btn_switch_list).setOnClickListener(view -> {
            String[] items = getResources().getStringArray(R.array.dialog_video_list);
            int itemSelected = sharedPref.getChannelViewType();
            new AlertDialog.Builder(getActivity())
                    .setTitle(R.string.title_setting_list)
                    .setSingleChoiceItems(items, itemSelected, (dialogInterface, position) -> {
                        sharedPref.updateChannelViewType(position);

                        if (position == 0) {
                            txt_current_video_list.setText(getResources().getString(R.string.single_choice_default));
                        } else if (position == 1) {
                            txt_current_video_list.setText(getResources().getString(R.string.single_choice_grid2));
                        }

                        Intent intent = new Intent(getActivity(), MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        startActivity(intent);

                        dialogInterface.dismiss();
                    })
                    .show();
        });
    }

    private void changeCategoryListViewType() {

        root_view.findViewById(R.id.btn_switch_category).setOnClickListener(view -> {
            String[] items = getResources().getStringArray(R.array.dialog_category_list);
            int itemSelected = sharedPref.getCategoryViewType();
            new AlertDialog.Builder(getActivity())
                    .setTitle(R.string.title_setting_category)
                    .setSingleChoiceItems(items, itemSelected, (dialogInterface, position) -> {
                        sharedPref.updateCategoryViewType(position);

                        if (position == 0) {
                            txt_current_category_list.setText(getResources().getString(R.string.single_choice_list));
                        } else if (position == 1) {
                            txt_current_category_list.setText(getResources().getString(R.string.single_choice_grid_2));
                        } else if (position == 2) {
                            txt_current_category_list.setText(getResources().getString(R.string.single_choice_grid_3));
                        }

                        Intent intent = new Intent(getActivity(), MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        intent.putExtra("category_position", "category_position");
                        startActivity(intent);

                        dialogInterface.dismiss();
                    })
                    .show();
        });
    }

    private void changePlayerMode() {

        root_view.findViewById(R.id.btn_switch_player_mode).setOnClickListener(view -> {
            String[] items = getResources().getStringArray(R.array.dialog_player_mode);
            int itemSelected = sharedPref.getPlayerMode();
            new AlertDialog.Builder(getActivity())
                    .setTitle(R.string.title_setting_player)
                    .setSingleChoiceItems(items, itemSelected, (dialogInterface, position) -> {
                        sharedPref.updatePlayerMode(position);
                        if (position == 0) {
                            txt_current_player_mode.setText(getResources().getString(R.string.player_portrait));
                        } else if (position == 1) {
                            txt_current_player_mode.setText(getResources().getString(R.string.player_landscape));
                        }
                        dialogInterface.dismiss();
                    })
                    .show();
        });
    }

    public void aboutDialog() {
        LayoutInflater layoutInflaterAndroid = LayoutInflater.from(getActivity());
        View view = layoutInflaterAndroid.inflate(R.layout.custom_dialog_about, null);
        final AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
        alert.setView(view);
        alert.setCancelable(false);
        alert.setPositiveButton(R.string.option_ok, (dialog, which) -> dialog.dismiss());
        alert.show();
    }

}