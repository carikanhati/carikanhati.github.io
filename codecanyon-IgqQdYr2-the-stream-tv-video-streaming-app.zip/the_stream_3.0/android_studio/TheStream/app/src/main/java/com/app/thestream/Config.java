package com.app.thestream;

public class Config {

    //your admin panel url
    public static final String ADMIN_PANEL_URL = "http://10.0.2.2/the_stream";

    //your api key which obtained from admin panel
    public static final String API_KEY = "cda11bx8aITlKsXCpNB7yVLnOdEGqg342ZFrQzJRetkSoUMi9w";

    //display category name in the channel list
    public static final boolean ENABLE_CHANNEL_LIST_CATEGORY_NAME = true;
    public static final boolean ENABLE_DIALOG_ON_CLOSE_PLAYER = true;

    //if you use RTL Language e.g : Arabic Language or other, set true
    public static final boolean ENABLE_RTL_MODE = false;

    //load more for next channel list
    public static final int LOAD_MORE = 20;

    //splash screen duration in millisecond
    public static final int SPLASH_TIME = 2000;

    //looping mode
    public static final boolean ENABLE_LOOPING_MODE = false;

}